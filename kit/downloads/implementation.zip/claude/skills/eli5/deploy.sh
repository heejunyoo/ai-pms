#!/usr/bin/env bash
# ELI20 페이지를 Vercel 에 배포한다.  사용: deploy.sh <파일.html> [슬러그] [--force] [--dry-run]
# check.py 에 ERROR 가 있으면 배포하지 않는다. --force 는 사용자 명시 승인 후에만 쓴다.
# 성공하면 마지막 줄에 URL 만 출력한다.
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
src="${1:-}"; shift || true
slug=""; force=0; dry=0
for arg in "$@"; do
  case "$arg" in
    --force) force=1 ;;
    --dry-run) dry=1 ;;
    *) [ -z "$slug" ] && slug="$arg" ;;
  esac
done

[ -n "$src" ] && [ -f "$src" ] || { echo "usage: deploy.sh <파일.html> [슬러그] [--force] [--dry-run]" >&2; exit 2; }
if [ "$dry" -eq 0 ]; then
  command -v vercel >/dev/null || { echo "vercel CLI 가 없다: npm i -g vercel" >&2; exit 2; }
  vercel whoami >/dev/null 2>&1 || { echo "vercel 로그인 필요: vercel login" >&2; exit 2; }
fi

if ! python3 "$here/check.py" "$src"; then
  if [ "$force" -eq 1 ]; then
    echo "!! ERROR 를 --force 로 무시하고 배포한다" >&2
  else
    echo "!! 정적 검사 ERROR — 배포 중단. 고치거나 --force." >&2
    exit 1
  fi
fi

# 슬러그: 없으면 파일명에서. Vercel 프로젝트명 규칙(소문자·숫자·하이픈)으로 정규화.
[ -n "$slug" ] || slug="$(basename "$src" .html)"
slug="$(printf '%s' "$slug" | tr '[:upper:]' '[:lower:]' | sed -e 's/[^a-z0-9-]/-/g' -e 's/--*/-/g' -e 's/^-//' -e 's/-$//')"
[ -n "$slug" ] || slug="$(date +%Y%m%d-%H%M%S)"
case "$slug" in eli5-*) ;; *) slug="eli5-$slug" ;; esac
slug="$(printf '%s' "$slug" | cut -c1-90)"

root="${ELI5_HOME:-$HOME/eli5}"
dir="$root/$slug"
mkdir -p "$dir"
cp "$src" "$dir/index.html"
cat > "$dir/vercel.json" <<'JSON'
{
  "headers": [
    { "source": "/(.*)", "headers": [{ "key": "X-Robots-Tag", "value": "noindex, nofollow" }] }
  ]
}
JSON

if [ "$dry" -eq 1 ]; then
  echo "▸ dry-run: 여기까지만 한다 — 실제 배포는 --dry-run 을 빼고 다시" >&2
  echo "  프로젝트 $slug · 스테이징 $dir · 파일 $(wc -c < "$dir/index.html") bytes" >&2
  exit 0
fi

echo "▸ 배포: $slug  ($dir)" >&2
url="$(cd "$dir" && vercel deploy --prod --yes 2>/dev/null | tail -n 1)"
case "$url" in
  https://*) ;;
  *) echo "배포 URL 을 못 받았다. 직접 확인: (cd $dir && vercel deploy --prod --yes)" >&2; exit 1 ;;
esac
echo "$url"
