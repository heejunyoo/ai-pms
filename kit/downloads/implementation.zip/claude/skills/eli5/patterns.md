# 구현 스니펫 — 처음 만들 때만 읽는다

전부 의존성 0. 복사해서 쓰되 개념에 맞게 도해는 새로 그린다.

## 뼈대

```html
<!doctype html><html lang="ko" data-explain-level="20"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>개념 이름</title><style>/* 아래 토큰 */</style></head>
<body>
  <header><span class="level">설명 깊이 · ELI20</span><h1>개념 이름</h1><p class="lede">한 문장 요약.</p></header>
  <figure class="stage"><svg viewBox="0 0 360 240" role="img" aria-label="관계도">…</svg></figure>
  <nav class="knobs" aria-label="단계 선택">…</nav>
  <p class="caption" aria-live="polite">지금 일어난 일.</p>
  <section class="cards">…</section>
<script>/* 아래 로직 */</script></body></html>
```

## 테마 토큰 (라이트 기본 + 다크 오버라이드)

```css
:root{--bg:#fbfaf8;--fg:#1c1b1a;--muted:#6b6763;--line:#d9d5cf;
      --node:#ffffff;--accent:#c96442;--dim:#c9c4bd;--card:#f2efea}
@media (prefers-color-scheme:dark){:root{--bg:#141413;--fg:#f5f4ef;--muted:#a3a09b;
      --line:#3a3835;--node:#1f1e1d;--accent:#e08c6d;--dim:#4a4744;--card:#1f1e1d}}
*{box-sizing:border-box}
body{margin:0;padding:20px 16px 56px;background:var(--bg);color:var(--fg);
     font:16px/1.55 -apple-system,BlinkMacSystemFont,"Apple SD Gothic Neo",system-ui,sans-serif;
     max-width:720px;margin-inline:auto;overflow-x:hidden}
.lede{color:var(--muted);margin:.3em 0 1.4em}
.stage{margin:0 0 18px;padding:8px 0}
svg{width:100%;height:auto;display:block}          /* 고정 px 폭 금지 */
```

## 반응형 SVG + 상태로 바뀌는 도형

좌표는 `viewBox` 안에서만 쓴다. 상태 변화는 **클래스 토글**로, 색·굵기·투명도는 CSS 가 맡는다.

```html
<svg viewBox="0 0 360 200">
  <g class="node" data-id="app"><rect x="12" y="70" width="92" height="52" rx="10"/>
    <text x="58" y="101" text-anchor="middle">앱</text></g>
  <g class="edge" data-step="1"><path d="M104 96 H236" marker-end="url(#a)"/>
    <text x="170" y="86" text-anchor="middle">요청</text></g>
  <defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6"
    orient="auto"><path d="M0 0 10 5 0 10z" fill="currentColor"/></marker></defs>
</svg>
```

```css
.node rect{fill:var(--node);stroke:var(--line);stroke-width:1.5;transition:.25s}
.node text{fill:var(--fg);font-size:13px}
.node.on rect{stroke:var(--accent);stroke-width:2.5}
.edge{color:var(--dim)}                      /* marker 가 currentColor 를 따라간다 */
.edge path{stroke:currentColor;stroke-width:2;fill:none;transition:.25s}
.edge text{fill:var(--muted);font-size:11px}
.edge.on{color:var(--accent)}
.edge.on text{fill:var(--accent)}
.edge.off{opacity:.18}
```

## 손잡이 ① 스텝퍼 — 단계형

```html
<nav class="knobs"><button data-go="-1" aria-label="이전">‹</button>
  <button class="step" data-step="1">1 요청</button>
  <button class="step" data-step="2">2 검증</button>
  <button class="step" data-step="3">3 응답</button>
  <button data-go="1" aria-label="다음">›</button></nav>
```

```js
const CAP = {1:"앱이 서버에 표를 보여준다.",2:"서버가 표가 진짜인지 본다.",3:"열쇠를 돌려준다."};
let cur = 1, MAX = 3;
function render(){
  document.querySelectorAll('.edge').forEach(e=>{
    const s = +e.dataset.step;
    e.classList.toggle('on',  s === cur);
    e.classList.toggle('off', s >  cur);          // 아직 안 온 흐름은 흐리게
  });
  document.querySelectorAll('.step').forEach(b=>b.setAttribute('aria-current', +b.dataset.step===cur));
  document.querySelector('.caption').textContent = CAP[cur];
}
document.querySelectorAll('.step').forEach(b=>b.onclick=()=>{cur=+b.dataset.step;render()});
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{
  cur=Math.min(MAX,Math.max(1,cur + +b.dataset.go)); render()});   // 되돌릴 수 있게
render();
```

## 손잡이 ② 토글 — 비교형

같은 도해 위에서 **구조가 바뀌어야** 한다. 카드 두 장을 나란히 놓는 것은 비교가 아니다.

```js
let mode = 'A';
function apply(){
  document.body.dataset.mode = mode;                       // CSS 가 받아 처리
  document.querySelector('#hop').setAttribute('opacity', mode==='A'?0:1);  // 중간 노드 등장
  document.querySelectorAll('[data-mode]').forEach(el=>
    el.classList.toggle('on', el.dataset.mode===mode));
}
```

## 손잡이 ③ 슬라이더 — 변수형

```js
const r = document.querySelector('#n');
r.oninput = () => {
  const v = +r.value;
  document.querySelector('#bar').setAttribute('width', 20 + v*3);   // 도형이 반응
  document.querySelector('.caption').textContent = `${v}명이면 ${v*(v-1)/2}쌍.`;
};
```

## 노드 상세 카드 — 접힌 채로 시작

```html
<details class="card"><summary>서버</summary><p>표가 진짜인지 확인하는 쪽.</p></details>
```

```css
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;
      padding:12px 14px;margin:8px 0}
summary{cursor:pointer;font-weight:600;min-height:44px;display:flex;align-items:center}
```

노드를 눌러 카드를 여는 연결:
```js
document.querySelectorAll('.node').forEach(g=>{
  g.style.cursor='pointer';
  g.onclick=()=>{const c=document.querySelector(`.card[data-id="${g.dataset.id}"]`);
    c.open=true; c.scrollIntoView({behavior:'smooth',block:'center'});
    document.querySelectorAll('.node').forEach(n=>n.classList.toggle('on', n===g));};
});
```

## 터치 타깃 · 손잡이 줄

```css
.knobs{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}
.knobs button{min-height:44px;min-width:44px;padding:0 14px;border-radius:10px;
  border:1px solid var(--line);background:var(--node);color:var(--fg);font-size:15px}
.knobs button[aria-current="true"]{background:var(--accent);border-color:var(--accent);color:#fff}
@media (min-width:768px){.stage{padding:16px 0}}
```

## 흔한 사고

- SVG `width="360"` 하드코딩 → 390px 에서 가로 스크롤. `viewBox` + CSS `width:100%` 로만.
- `<text>` 안 한글이 도형 밖으로 → 노드 라벨 8자 상한(SKILL §3)을 지키면 안 넘친다.
- hover 로만 뜨는 툴팁 → 터치에선 안 보인다. 클릭으로.
- `aria-live="polite"` 없는 캡션 → 스크린리더가 변화를 못 읽는다.
