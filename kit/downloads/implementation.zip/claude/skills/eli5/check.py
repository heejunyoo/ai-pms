#!/usr/bin/env python3
"""ELI20 인터랙티브 페이지 정적 검사. ERROR 가 있으면 exit 1 (deploy.sh 가 이걸 보고 막는다).

정적 검사는 '배포해도 안 깨지는가'까지만 본다. '이해가 되는가'는 사람이 열어봐야 안다.
"""
import re
import sys

PARA_LIMIT = 240            # 긴 문단은 나눠서 보여준다


def strip_blocks(html: str) -> str:
    out = re.sub(r"(?is)<script\b.*?</script>", " ", html)
    out = re.sub(r"(?is)<style\b.*?</style>", " ", out)
    return out


def css_text(html: str) -> str:
    """CSS 만 모은다 — <style> 블록 + style="" 속성. 폭·터치타깃 검사는 여기서 본다."""
    parts = re.findall(r"(?is)<style\b[^>]*>(.*?)</style>", html)
    parts += re.findall(r"""(?i)\sstyle\s*=\s*['"]([^'"]*)""", html)
    return "\n".join(parts)


def visible_text(html: str) -> str:
    out = strip_blocks(html)
    out = re.sub(r"(?is)<!--.*?-->", " ", out)
    out = re.sub(r"(?s)<[^>]+>", " ", out)
    out = re.sub(r"&[a-zA-Z#0-9]+;", " ", out)
    return re.sub(r"\s+", " ", out).strip()


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: check.py <파일.html>")
        return 2
    path = sys.argv[1]
    try:
        with open(path, encoding="utf-8") as fh:
            html = fh.read()
    except OSError as exc:
        print(f"ERROR  파일을 열 수 없다: {exc}")
        return 1

    errors: list[str] = []
    warns: list[str] = []
    notes: list[str] = []
    if not re.search(r'(?i)<html\b[^>]*\bdata-explain-level=["\']20["\']', html):
        errors.append('data-explain-level="20"이 없다 — 이 스킬은 ELI20만 지원한다')

    # 1. 자기완결 — 외부 리소스
    ext = []
    for m in re.finditer(r"""(?i)(?:src|href)\s*=\s*['"](https?:)?//([^/'"]+)""", html):
        ext.append(m.group(2))
    for m in re.finditer(r"""(?i)url\(\s*['"]?(?:https?:)?//([^/'")]+)""", html):
        ext.append(m.group(1))
    if ext:
        errors.append(f"외부 리소스 {len(ext)}건 — 자기완결이 아니다: {sorted(set(ext))[:5]}")
    if re.search(r"(?i)\b(fetch|XMLHttpRequest|importScripts)\s*\(\s*['\"]https?://", html):
        errors.append("런타임 외부 호출(fetch/XHR)이 있다 — 배포본에서 조용히 실패한다")

    # 2. 모바일 기본
    if not re.search(r"""(?i)<meta[^>]+name\s*=\s*['"]viewport""", html):
        errors.append("viewport 메타가 없다 — 모바일에서 축소되어 뜬다")
    if not re.search(r"(?i)@media", html):
        warns.append("@media 쿼리가 하나도 없다 — 데스크톱 폭에서 늘어질 수 있다")
    css = css_text(html)
    fixed = re.findall(r"(?i)(?<![-a-z])width\s*:\s*(\d{3,})px", css)
    wide = [w for w in fixed if int(w) > 420]
    if wide:
        warns.append(f"420px 초과 고정 폭 {len(wide)}건 {wide[:3]} — 390px 에서 가로 스크롤 위험")
    tap_px = re.search(r"(?i)(min-height|height)\s*:\s*(4[4-9]|[5-9]\d|\d{3,})px", css)
    tap_rem = re.search(r"(?i)(min-height|height)\s*:\s*(2\.[5-9]|[3-9])[\d.]*rem", css)
    if not tap_px and not tap_rem:
        warns.append("44px 이상 터치 타깃 지정이 안 보인다 — 버튼 높이를 확인한다")

    # 3. 도해가 본문인가
    svgs = re.findall(r"(?is)<svg\b[^>]*>", html)
    no_vb = [s for s in svgs if "viewbox" not in s.lower()]
    if no_vb:
        errors.append(f"viewBox 없는 <svg> {len(no_vb)}개 — 반응형으로 줄지 않는다")
    notes.append(f"svg {len(svgs)}개")

    # 4. 인터랙션 — 누르면 그림이 바뀌는가
    handlers = len(re.findall(r"addEventListener\s*\(", html)) + len(re.findall(r"(?i)\son(click|input|change)\s*=", html))
    buttons = len(re.findall(r"(?i)<button\b", html)) + len(re.findall(r"""(?i)<input[^>]+type\s*=\s*['"]range""", html))
    if handlers < 1:
        errors.append(f"인터랙션 핸들러가 {handlers}개뿐이다 — 눌러볼 것이 없다")
    if buttons < 2:
        warns.append(f"버튼/슬라이더가 {buttons}개다 — 손잡이가 충분한지 본다")
    mutates = re.search(r"(classList\.|setAttribute\s*\(|\.style\.|\.setAttributeNS)", html)
    if not mutates:
        errors.append("DOM 을 바꾸는 코드가 없다 — 눌러도 그림이 안 바뀐다")
    svg_mutate = re.search(r"(?i)(classList\.[a-z]+\s*\(\s*['\"][^'\"]*(node|arrow|step|edge|path|active|on|hi)|setAttribute\s*\(\s*['\"](x|y|cx|cy|d|points|stroke|fill|opacity|transform|r|x1|x2|y1|y2))", html)
    if svgs and not svg_mutate:
        warns.append("SVG 속성/클래스를 바꾸는 코드가 안 보인다 — 텍스트만 바뀌는 페이지인지 확인한다")
    notes.append(f"핸들러 {handlers}개 · 버튼 {buttons}개")

    # 5. 설명 깊이 · 읽기 편한 단락
    text = visible_text(html)
    n = len(text)
    longs = [len(visible_text(m)) for m in re.findall(r"(?is)<p\b[^>]*>(.*?)</p>", html)]
    over = [c for c in longs if c > PARA_LIMIT]
    if over:
        warns.append(f"{PARA_LIMIT}자 넘는 문단 {len(over)}개 {over[:3]} — 나눠서 보여준다")
    notes.append(f"ELI20 · 산문 {n}자 (총량 제한 없음)")

    # 6. 테마 · 제목
    if not re.search(r"(?i)prefers-color-scheme", html):
        warns.append("다크 모드 대응이 없다 — 다크 브라우저에서 대비가 무너질 수 있다")
    if not re.search(r"(?is)<title\b[^>]*>\s*\S", html):
        warns.append("<title> 이 비었다 — 탭·공유 카드에 파일명이 뜬다")
    if re.search(r"(?i)\b(alert|confirm|prompt)\s*\(", html):
        warns.append("alert/confirm 사용 — 모달은 모바일에서 흐름을 끊는다")

    print(f"── {path}")
    for e in errors:
        print(f"ERROR  {e}")
    for w in warns:
        print(f"WARN   {w}")
    print(f"INFO   {' · '.join(notes)}")
    print(f"── ERROR {len(errors)} · WARN {len(warns)}")
    if not errors:
        print("정적 검사 통과. 다음은 390px 실제 렌더 확인이다(정적 통과 ≠ 화면 멀쩡).")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
