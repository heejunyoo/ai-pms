#!/usr/bin/env python3
"""안전 게이트 — 유일한 하드 차단(exit-2). 되돌릴 수 없는 위험만.

원칙(보고서 L2): 저오탐. 고신뢰 비밀정보/파괴적 경로만 막고, 애매하면 통과.
차단이 정당한 작업을 끊으면 그 자체가 비용이므로 패턴을 좁게 유지한다.

Claude Code PreToolUse 훅: stdin 으로 {tool_name, tool_input} 수신.
exit 2 + stderr = 하드 차단(모델에게 사유 전달). 그 외 exit 0 = 통과.
예기치 못한 입력에는 fail-open(통과) — 훅 크래시로 모든 편집을 막지 않기 위함.

커버리지:
  (1) 파일 편집 도구의 file_path — 비밀정보/파괴적 경로
  (2) Bash 명령의 **리다이렉트 대상**(`> f`, `>> f`, `tee f`) — 같은 패턴
  (3) 테스트 파일의 **테스트 제거·skip 부여** — 안전 바닥 "기존 테스트 삭제/skip"

셸 문법을 완전 파싱하지 않는다 — 명확한 기록 경로만 본다. 우회로가 남는 것은 수용한다.
이 층의 목적은 완전 방어가 아니라 사고 방지이고, 오탐으로 정당한 작업을 끊으면
게이트 전체가 꺼지기 때문이다.
"""
import json
import os
import re
import sys

# 비밀정보 파일 — 기록 시 차단(파일명/경로 기준, 고신뢰만)
SECRET_PATTERNS = [
    r"(^|/)\.env(\.[^/]+)?$",          # .env, .env.local, .env.production ...
    r"(^|/)\.aws/credentials$",
    r"(^|/)\.ssh/",                     # ~/.ssh/ 하위 전체
    r"(^|/)id_(rsa|ed25519|ecdsa|dsa)(\.pub)?$",
    r"\.(pem|key|p12|pfx|keystore)$",
    r"(^|/)\.netrc$",
    r"(^|/)credentials(\.json)?$",
    r"(^|/)service[-_]?account.*\.json$",
]

# 예시·템플릿 꼬리표가 붙은 것은 비밀정보가 아니다 — 실측에서 나온 오탐(.env.local.example)
NOT_SECRET_SUFFIX = r"\.(example|sample|template|dist|local)$"

# 파괴적/시스템 경로 — 기록 시 차단
DESTRUCTIVE_PATTERNS = [
    r"^/etc/",
    r"^/System/",
    r"^/Library/LaunchDaemons/",
    r"(^|/)\.git/hooks/",              # git 훅 무단 주입 방지
]


# Bash 명령에서 "기록 대상"을 뽑는다 — 리다이렉트와 tee 만. 좁게 유지한다.
_TARGET = r"""("[^"]+"|'[^']+'|[^\s;|&<>()]+)"""
WRITE_PATTERNS = [
    rf"(?<![0-9\w])>>?\s*{_TARGET}",          # > f, >> f  (2>&1, >&2 는 제외)
    rf"\btee\b\s+(?:-a\s+)?{_TARGET}",        # tee f, tee -a f
]


def write_targets(command):
    """명령에서 기록 대상 경로들을 뽑는다. 애매하면 아무것도 반환하지 않는다."""
    out = []
    for pat in WRITE_PATTERNS:
        for m in re.finditer(pat, command):
            t = m.group(1).strip("\"'")
            if t and not t.startswith("&"):
                out.append(t)
    return out


# ── 테스트 보호 ──────────────────────────────────────────────────────
# 안전 바닥 중 유일하게 "파일 편집으로 드러나는" 항목. 테스트 파일에서
# 테스트가 줄거나 skip 이 붙으면 차단한다. 좁게 유지 — 테스트 파일이 아니면 보지 않는다.

TEST_FILE_PATTERNS = [
    r"(^|/)tests?/",
    r"(^|/)__tests__/",
    r"(^|/)spec/",
    r"(^|/)test_[^/]+\.py$",
    r"(^|/)[^/]+_test\.(py|go|rb|ts|js|tsx|jsx)$",
    r"(^|/)[^/]+\.(test|spec)\.[jt]sx?$",
    r"(^|/)[^/]*Tests?\.(java|kt|cs|scala)$",
]

# 테스트 1개의 선언 — 개수가 줄면 삭제로 본다
TEST_DECL_PATTERNS = [
    r"\bdef test_\w+",                     # pytest / unittest
    r"\bfunc Test\w+",                     # go
    r"^\s*(?:it|test)\s*(?:\.each\([^)]*\))?\s*\(",   # jest / vitest / mocha
    r"@Test\b", r"\[Test\]", r"\[Fact\]",  # junit / nunit / xunit
    r"#\[test\]",                          # rust
]

# skip 부여 — 새로 생기면 차단
SKIP_PATTERNS = [
    r"@pytest\.mark\.skip", r"@unittest\.skip", r"\bpytest\.skip\s*\(",
    r"\b(?:it|test|describe)\.skip\s*\(", r"\bx(?:it|test|describe)\s*\(",
    r"@Ignore\b", r"@Disabled\b", r"\bt\.Skipf?\s*\(", r"#\[ignore\]",
]


def is_test_file(path):
    return any(re.search(p, path) for p in TEST_FILE_PATTERNS)


def count_hits(text, patterns):
    return sum(len(re.findall(p, text, re.M)) for p in patterns)


def check_test_edit(path, before, after):
    """테스트가 줄거나 skip 이 늘면 차단. 테스트 파일이 아니면 아무것도 하지 않는다."""
    if not is_test_file(path):
        return

    reason = None
    lost = count_hits(before, TEST_DECL_PATTERNS) - count_hits(after, TEST_DECL_PATTERNS)
    if lost > 0:
        reason = f"테스트 선언 {lost}개가 사라집니다"
    else:
        added = count_hits(after, SKIP_PATTERNS) - count_hits(before, SKIP_PATTERNS)
        if added > 0:
            reason = f"skip/ignore 표시 {added}개가 추가됩니다"

    if reason:
        sys.stderr.write(
            f"[safety_gate] 차단: 기존 테스트를 무력화하는 변경 → {path}\n"
            f"근거: {reason}.\n"
            f"기능 제거 등으로 의도한 것이면 사용자에게 확인받고 진행하세요"
            f"(승인 후에는 이 훅을 잠시 끄거나 사용자가 직접 편집)."
        )
        sys.exit(2)


def check(path, shown=None):
    """차단 대상이면 사유를 쓰고 exit 2. 아니면 반환."""
    norm = os.path.expanduser(path)
    label = shown or path

    for pat in SECRET_PATTERNS:
        if re.search(pat, norm) and not re.search(NOT_SECRET_SUFFIX, norm):
            sys.stderr.write(
                f"[safety_gate] 차단: 비밀정보로 보이는 파일에 기록 시도 → {label}\n"
                f"의도한 것이면 사용자에게 확인 후 훅 예외로 진행하세요."
            )
            sys.exit(2)

    for pat in DESTRUCTIVE_PATTERNS:
        if re.search(pat, norm):
            sys.stderr.write(
                f"[safety_gate] 차단: 파괴적/시스템 경로 기록 시도 → {label}\n"
                f"인프라/시스템 변경은 사용자 승인이 필요합니다(Ask-Before-Act)."
            )
            sys.exit(2)


def edit_texts(path, tool_input):
    """(변경 전, 변경 후) 텍스트를 뽑는다. Edit/MultiEdit 는 payload 로, Write 는 디스크와 대조."""
    if "old_string" in tool_input:                    # Edit
        return tool_input.get("old_string") or "", tool_input.get("new_string") or ""

    edits = tool_input.get("edits")                   # MultiEdit
    if isinstance(edits, list):
        before = "\n".join(e.get("old_string") or "" for e in edits if isinstance(e, dict))
        after = "\n".join(e.get("new_string") or "" for e in edits if isinstance(e, dict))
        return before, after

    if "content" in tool_input:                       # Write — 기존 파일이 있을 때만 의미가 있다
        try:
            before = open(os.path.expanduser(path), encoding="utf-8", errors="replace").read()
        except OSError:
            return "", ""                             # 새 파일 — 비교 대상 없음
        return before, tool_input.get("content") or ""

    return "", ""


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)  # fail-open

    tool_input = data.get("tool_input") or {}

    path = tool_input.get("file_path") or tool_input.get("path") or ""
    if path:
        check(path)
        check_test_edit(path, *edit_texts(path, tool_input))

    command = tool_input.get("command") or ""
    if command:
        for t in write_targets(command):
            check(t, shown=f"{t}  (명령: {command[:60]})")

    sys.exit(0)


if __name__ == "__main__":
    main()
