"""Regression tests for observable verification ordering and command recognition."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('session_gate', Path(__file__).with_name('session_gate.py'))
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


class VerificationTests(unittest.TestCase):
    def scan(self, events):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.jsonl') as f:
            for event in events:
                f.write(json.dumps({'message': {'content': [event]}}) + '\n')
            f.flush()
            return gate.scan(f.name)[2]

    def edit(self):
        return {'type': 'tool_use', 'name': 'Edit', 'input': {'file_path': '/project/src/app.py'}}

    def command(self, value='pytest'):
        return {'type': 'tool_use', 'name': 'Bash', 'id': 'v', 'input': {'command': value}}

    def result(self, failed=False):
        return {'type': 'tool_result', 'tool_use_id': 'v', 'is_error': failed}

    def test_success_after_edit(self):
        self.assertTrue(self.scan([self.edit(), self.command(), self.result()]))

    def test_success_before_edit_is_stale(self):
        self.assertFalse(self.scan([self.command(), self.result(), self.edit()]))

    def test_late_result_of_old_verification_is_stale(self):
        self.assertFalse(self.scan([self.command(), self.edit(), self.result()]))

    def test_missing_result_is_not_success(self):
        self.assertFalse(self.scan([self.edit(), self.command()]))

    def test_failed_result_is_not_success(self):
        self.assertFalse(self.scan([self.edit(), self.command(), self.result(True)]))

    def test_quoted_or_unrelated_commands(self):
        for command in ['echo pytest', 'python3 helper.py', "echo 'pytest; npm test'", 'cat pytest.log']:
            with self.subTest(command=command):
                self.assertFalse(gate.is_verification(command))

    def test_supported_commands(self):
        for command in ['pytest', 'npm run test:regression', 'python3 -m unittest', 'python3 scripts/verify.py', 'cargo test', 'cd project && npm test']:
            with self.subTest(command=command):
                self.assertTrue(gate.is_verification(command))

    def test_negative_completion(self):
        self.assertFalse(gate.claims_done('아직 완료되지 않았습니다. 검증할 수 없습니다.'))
        self.assertFalse(gate.claims_done('Not yet completed.'))
        self.assertTrue(gate.claims_done('구현을 완료했습니다. 배포는 아직 완료되지 않았습니다.'))

    def test_multiline_command(self):
        self.assertTrue(gate.is_verification('echo preparing\npytest'))
        self.assertFalse(gate.is_verification('echo "pytest\nnpm test"'))


if __name__ == '__main__':
    unittest.main()
