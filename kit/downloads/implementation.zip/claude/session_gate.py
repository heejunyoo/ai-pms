#!/usr/bin/env python3
"""세션 게이트 — 마지막 편집 이후 검증 흔적을 확인하는 제한된 휴리스틱이다. 이벤트는 Stop 하나뿐이다.

  Stop  모델이 "완료"를 주장했는데 코드가 바뀌었고 테스트·빌드 실행 기록이 없으면 차단(exit 2).
        큰 변경인데 독립 검토 기록도 없으면 같은 메시지에 함께 싣는다(루프 A 발동).

설계 제약(보고서):
- **advisory 금지.** 경고만 하는 훅은 폐기된 구조다. 차단하거나, 넣지 않는다.
- **발동 조건을 좁게.** 코드가 실제로 바뀐 턴 + 완료 주장 + 검증 기록 없음, 세 조건이 모두 맞을 때만.
- **세션당 최대 1회 차단.** 마커 파일로 보장한다. 무한 루프 방지이자 마찰 상한(세션당 1턴)이다.
- **관측 인프라를 만들지 않는다.** 상태는 마커 파일뿐. 발동률 로그는 두지 않는다.
- 예기치 못한 입력에는 fail-open — 훅이 세션을 인질로 잡지 않는다.

2026-08 감축: SessionStart 자가검진(7일 주기 verify)을 걷어냈다. 하네스 회귀 검출은
"상시 러너를 두지 않는다"(CORE.md §4 루프 B)가 원칙이고, 주기 실행은 그 원칙에서 후퇴한
것이었다. 검증은 하네스를 실제로 고친 사람이 `harness/verify.py` 로 한 번 돌린다.
"""
import json
import os
import re
import shlex
import sys
import time
from pathlib import Path

HOME = Path.home()
CLAUDE = HOME / ".claude"
STATE = CLAUDE / "harness" / "state"

# 검증 대상이 되는 "코드" — 문서·설정만 바꾼 세션은 발동하지 않는다
CODE_EXT = {
    ".py", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".java", ".go", ".rs", ".rb",
    ".php", ".c", ".h", ".cc", ".cpp", ".cs", ".kt", ".swift", ".scala", ".sh", ".sql",
}
EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}

# 실행 검증의 증거 — 테스트·빌드 러너, 그리고 **바꾼 것을 실제로 돌려 본 흔적**.
# 러너만 보면 스크립트를 직접 실행하거나 엔드포인트를 찔러 확인한 세션을 놓친다(실측에서 확인됨).
def is_verification(command):
    """Recognize actual command positions, not quoted test names."""
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=";&|\n")
        lexer.whitespace = " \t\r"
        lexer.whitespace_split = True
        tokens = list(lexer)
    except ValueError:
        return False
    segments, current = [], []
    for token in tokens + [";"]:
        if token and all(c in ";&|\n" for c in token):
            if current:
                segments.append(current)
            current = []
        else:
            current.append(token)
    for argv in segments:
        while argv and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*=.*", argv[0]):
            argv = argv[1:]
        if not argv:
            continue
        executable, args = os.path.basename(argv[0]), argv[1:]
        if executable in {"pytest", "py.test", "tox", "nose2", "jest", "vitest", "mocha", "rspec", "tsc", "mypy", "ruff", "eslint"}:
            return True
        if executable in {"npm", "pnpm", "yarn", "bun"}:
            if args and args[0] == "run":
                args = args[1:]
            if args and re.fullmatch(r"(?:test|build|typecheck|lint|verify|check)(?::[\w-]+)?", args[0]):
                return True
        if executable in {"go", "cargo", "swift", "dotnet"} and args and args[0] in {"test", "build", "check"}:
            return True
        if executable in {"python", "python3", "node", "bash", "sh"}:
            if args[:2] in [["-m", "pytest"], ["-m", "unittest"]]:
                return True
            if args and re.match(r"(?:test|verify|check)(?:[_.-]|$)", os.path.basename(args[0])):
                return True
    return False

# 완료 주장 — 이 표현이 없으면 차단하지 않는다(작업 도중의 턴은 건드리지 않는다)
DONE_RE = re.compile(
    r"(완료|끝났|끝냈|마쳤|적용했|반영했|구현했|수정했|고쳤|해결했|됐습니다|되었습니다"
    r"|\bdone\b|\bfinished\b|\bcompleted?\b|\bimplemented\b|\bfixed\b|all set)",
    re.I,
)
# 규칙 이름을 인용한 것은 완료 주장이 아니다 — 실측에서 나온 오탐
QUOTE_RE = re.compile(r"완료 ?= ?(검증|실제)|done ?= ?verified", re.I)

# 독립 검토의 증거 — **실제 호출만** 센다.
# 옛 구현은 트랜스크립트의 원시 라인에 정규식을 걸었는데, 세션 시작 시 주입되는 번들 skill
# 목록 안에 "code-review" 문자열이 들어 있어 사실상 항상 참이었다(실측 2026-07-29:
# 42개 세션 중 39개가 이 문자열을 포함했고, 미포함 3개는 11줄 이하의 빈 세션이었다).
# 즉 "큰 변경인데 리뷰 없음" 분기는 한 번도 발동할 수 없었다. 신호를 호출 지점으로 좁힌다.
REVIEW_SKILLS = {"code-review", "security-review", "review"}
REVIEW_CMD_RE = re.compile(r"<command-name>\s*/?(code-review|security-review|review)\b", re.I)
REVIEW_AGENT_RE = re.compile(r"review", re.I)

# "큰 변경" — 이 이상이면 독립 검토 기록을 함께 본다.
# 값은 취향이 아니라 **마찰 상한(세션당 <10%)에서 역산**한 것이다. 리뷰 탐지를 실제 호출
# 기준으로 고치자 옛 임계값(5파일·15편집)의 실측 차단률이 8/44 = 18.2% 로 상한을 넘었다
# (교정 전에는 분기가 죽어 있어 0% 였다). 15/30 에서 2/44 = 4.5% — 상한 안에 여유를 두고 든다.
# 임계값을 바꾸면 BUILD.md 의 replay 로 다시 재고, 상한을 넘으면 되돌린다.
BIG_FILES = 15
BIG_EDITS = 30


def stop_marker(session_id):
    return STATE / f"stop-{re.sub(r'[^A-Za-z0-9_-]', '', session_id or 'unknown')}"


def scan(transcript_path):
    """트랜스크립트에서 코드 편집 · 검증 실행 · 검토 흔적을 센다."""
    files, edits, reviewed = set(), 0, False
    verify_ids, verified, generation = {}, False, 0
    try:
        fh = open(transcript_path, encoding="utf-8", errors="replace")
    except OSError:
        return files, edits, False, reviewed        # 트랜스크립트를 못 읽음 — 미검증으로 두되
                                                    # files 가 비어 있어 on_stop 이 통과시킨다

    with fh:
        for line in fh:
            try:
                rec = json.loads(line)
            except Exception:
                continue
            content = (rec.get("message") or {}).get("content")
            if isinstance(content, str):                     # 사용자가 친 슬래시 명령
                if REVIEW_CMD_RE.search(content):
                    reviewed = True
                continue
            if not isinstance(content, list):
                continue
            for blk in content:
                if not isinstance(blk, dict):
                    continue
                if blk.get("type") == "tool_result":
                    if verify_ids.get(blk.get("tool_use_id")) == generation:
                        verified = (blk.get("is_error") not in (True, "true", "True")
                                    and not re.search(r"Exit code [1-9]\d*", str(blk.get("content", ""))))
                    continue
                if blk.get("type") == "text":
                    if REVIEW_CMD_RE.search(blk.get("text") or ""):
                        reviewed = True
                    continue
                if blk.get("type") != "tool_use":
                    continue
                name, inp = blk.get("name"), blk.get("input") or {}
                if name == "Skill":
                    if str(inp.get("skill") or "").lower() in REVIEW_SKILLS:
                        reviewed = True
                elif name in ("Agent", "Task"):
                    if REVIEW_AGENT_RE.search(str(inp.get("subagent_type") or "")):
                        reviewed = True
                elif name in EDIT_TOOLS:
                    p = inp.get("file_path") or inp.get("notebook_path") or ""
                    if os.path.splitext(p)[1].lower() in CODE_EXT:
                        files.add(p)
                        edits += 1
                        generation += 1
                        verified = False
                elif name == "Bash":
                    if is_verification(inp.get("command") or ""):
                        verify_ids[blk.get("id")] = generation

    # A completed recognized verification after the latest observed edit is required.
    return files, edits, verified, reviewed


def claims_done(msg):
    text = QUOTE_RE.sub("", msg or "")
    text = re.sub(r"(?:완료|해결|수정|구현)(?:되지|하지)\s*(?:않|못)[^.!?\n]*", "", text)
    text = re.sub(r"\b(?:not|never)\s+(?:yet\s+)?(?:done|finished|complete[d]?|fixed|implemented)\b", "", text, flags=re.I)
    return bool(DONE_RE.search(text))


def on_stop(data):
    if not claims_done(data.get("last_assistant_message")):
        return 0                                    # 완료를 주장하지 않은 턴 — 건드리지 않는다

    marker = stop_marker(data.get("session_id"))
    if marker.exists():
        return 0                                    # 세션당 1회 — 마찰 상한이자 루프 방지

    files, edits, verified, reviewed = scan(data.get("transcript_path") or "")
    if not files:
        return 0                                    # 코드 변경 없음 — 문서·설정 세션은 통과

    reasons = []
    if not verified:
        reasons.append(
            "이 세션에서 코드가 바뀌었는데 테스트·빌드를 실행한 기록이 없습니다.\n"
            "  변경: " + ", ".join(sorted(os.path.basename(f) for f in files)[:5])
            + (" 외" if len(files) > 5 else "")
        )
    if (len(files) >= BIG_FILES or edits >= BIG_EDITS) and not reviewed:
        reasons.append(
            f"큰 변경({len(files)}파일 · {edits}회 편집)인데 독립 검토 기록이 없습니다 "
            "— 변경 범위와 위험에 맞는 검토 근거를 남기세요."
        )
    if not reasons:
        return 0

    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(str(int(time.time())), encoding="utf-8")
    sys.stderr.write(
        "[session_gate] 완료 보고 전 확인이 필요합니다 (안전 바닥: 완료 = 실제 실행 검증 통과).\n"
        + "".join(f"- {r}\n" for r in reasons)
        + "지금 검증을 실행하거나, 검증할 수 없는 이유를 사용자에게 밝히세요. "
        "이 확인은 세션당 1회만 발동합니다."
    )
    return 2


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        sys.exit(0)                                 # fail-open

    try:
        if data.get("hook_event_name") == "Stop":
            sys.exit(on_stop(data))
    except Exception:
        sys.exit(0)                                 # fail-open
    sys.exit(0)


if __name__ == "__main__":
    main()
