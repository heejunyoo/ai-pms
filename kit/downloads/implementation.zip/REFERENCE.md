# Harness Kit implementation / 구현 소스

Start with codex.md or claude.md in the guide ZIP. Copy complete skill folders, including SKILL.md and supporting files. Back up and merge existing settings. These files do not install themselves. Python 3.11+; default macOS/Linux home paths. Windows paths and shell commands need adaptation. Source comments retain their original language. Ponytail and Graphify are optional third-party tools and are not included; use the skills guide for installation and verification.

안내 ZIP의 codex.md 또는 claude.md를 따라 배치합니다. 스킬은 SKILL.md와 보조 파일을 포함해 폴더 단위로 옮기세요. 기존 설정은 백업 후 병합합니다. Python 3.11 이상, macOS·Linux 기본 홈 경로 기준입니다. Windows에서는 경로와 셸 명령을 조정해야 합니다. Ponytail·Graphify는 포함되지 않는 선택 설치 도구입니다. 설치·검증 절차는 스킬 안내를 참고하세요.

For hook capture, use ai-pms.md in the guide ZIP. For full central multi-user dashboard adoption, use https://github.com/heejunyoo/ai-pms/blob/main/docs/adoption.md and https://ai-pms-dashboard.vercel.app (synthetic offline sample); source: https://github.com/heejunyoo/ai-pms. The local viewer is a personal reference, not the central product.

The activity/ package contains a local logger, offline workflow viewer and explicitly synthetic project example. Start a project without logs or select activity/example-project.jsonl yourself. Choose the basis for a next Agent task, export its Markdown packet, and save the complete project JSONL separately. Follow activity/README.md and merge command hooks into existing settings. Local checks do not prove application hook delivery.

activity/에는 로컬 기록기, 오프라인 워크플로 뷰어, 합성 프로젝트 예시가 포함됩니다. 기록 없이 새 프로젝트를 시작하거나 activity/example-project.jsonl을 직접 선택하세요. 다음 Agent 작업에 적용할 기준을 선택해 Markdown 패킷을 받고, 프로젝트 전체 JSONL은 별도로 저장합니다. activity/README.md를 따라 기존 설정에 명령 훅을 병합하세요. 로컬 검사 통과는 앱의 훅 전달 증거가 아닙니다.

| Bundle / 묶음 | Destination / 배치 위치 |
|---|---|
| codex/safety_gate.py | ~/.codex/hooks/safety_gate.py |
| codex/docs/ | ~/.codex/docs/ |
| codex/skills/* | ~/.codex/skills/* |
| handoff/ | ~/.agents/skills/handoff/ |
| skills/* | ~/.agents/skills/* |
| claude/*.py | ~/.claude/hooks/ |
| claude/docs/ | ~/.claude/docs/ |
| claude/skills/* | ~/.claude/skills/* |
| claude-handoff/ | ~/.claude/skills/handoff/ |
| activity/ | ~/.agents/harness-activity/ |

Configure accounts, models, MCP connections, personal memory, and project permissions separately. No credentials or personal configuration are included.
