# User intent

Apply an IP-based request limit to the public HTTP API so requests over the limit receive HTTP 429 and a Retry-After header.
