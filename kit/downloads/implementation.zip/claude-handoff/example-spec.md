# Request limit specification

For the public HTTP API, count requests by client IP in a sliding window. Requests above the configured limit receive HTTP 429 and a Retry-After header. Keep health checks exempt and verify the behavior through the public router.
