"""Fail-closed, local source/spec receipt checks for handoff plans."""
import hashlib
import json
from pathlib import Path


def resolve_ref(ref, base_dir, cwd=None):
    """Resolve refs beside the plan first, then from the caller's cwd."""
    cwd = Path.cwd() if cwd is None else Path(cwd)
    path = Path(ref)
    if path.is_absolute():
        return path
    candidates = [Path(base_dir) / path]
    if cwd is not None:
        candidates.append(Path(cwd) / path)
    return next((p for p in candidates if p.is_file()), candidates[0])


def _read(path, label, errs):
    try:
        return path.read_bytes()
    except OSError as exc:
        errs.append(f"intent_guard.{label}: cannot read {path}: {exc}")
        return None


def _sha256(data):
    return hashlib.sha256(data).hexdigest()


def check_intent_guard(plan, base_dir, errs, cwd=None):
    """Validate file receipts and requirement mapping; semantics remain human-reviewed."""
    guard = plan.get("intent_guard")
    if not isinstance(guard, dict):
        errs.append("intent_guard: missing required source/spec alignment evidence")
        return []
    author = plan.get("author")
    reqs = guard.get("requirements")
    if not isinstance(reqs, list) or not reqs:
        errs.append("intent_guard.requirements: must be a non-empty array")
        reqs = []
    ids = [r.get("id") for r in reqs if isinstance(r, dict)]
    if len(ids) != len(reqs) or any(not isinstance(i, str) or not i for i in ids):
        errs.append("intent_guard.requirements: each item needs a non-empty id")
    ids = [i for i in ids if isinstance(i, str) and i]
    if len(set(ids)) != len(ids):
        errs.append("intent_guard.requirements: duplicate requirement id")

    source = resolve_ref(str(guard.get("source_ref", "")), base_dir, cwd)
    spec = resolve_ref(str(plan.get("spec_ref", "")), base_dir, cwd)
    source_bytes = _read(source, "source_ref", errs)
    spec_bytes = _read(spec, "spec_ref", errs)
    source_text = source_bytes.decode("utf-8", errors="replace") if source_bytes is not None else ""
    for i, req in enumerate(reqs):
        if not isinstance(req, dict):
            continue
        quote, outcome = req.get("quote"), req.get("outcome")
        if not isinstance(quote, str) or not quote or quote not in source_text:
            errs.append(f"intent_guard.requirements[{i}].quote: not an exact substring of source")
        if not isinstance(outcome, str) or len(outcome.strip()) < 8:
            errs.append(f"intent_guard.requirements[{i}].outcome: must be at least 8 characters")

    review_path = resolve_ref(str(guard.get("review_ref", "")), base_dir, cwd)
    raw_review = _read(review_path, "review_ref", errs)
    review = None
    if raw_review is not None:
        try:
            review = json.loads(raw_review.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            errs.append(f"intent_guard.review_ref: invalid JSON: {exc}")
    if not isinstance(review, dict):
        errs.append("intent_guard.review_ref: missing valid independent review receipt")
        return ids
    reviewer = review.get("reviewer")
    if (not isinstance(author, str) or not author.strip()
            or not isinstance(reviewer, str) or not reviewer.strip()
            or reviewer.strip() == author.strip()):
        errs.append("intent_guard.review: reviewer must differ from plan author")
    if review.get("verdict") != "aligned":
        errs.append("intent_guard.review: verdict must be aligned (blocked plans cannot dispatch)")
    if source_bytes is not None and review.get("source_sha256") != _sha256(source_bytes):
        errs.append("intent_guard.review: stale or mismatched source_sha256")
    if spec_bytes is not None and review.get("spec_sha256") != _sha256(spec_bytes):
        errs.append("intent_guard.review: stale or mismatched spec_sha256")
    covered = review.get("requirements_covered")
    if (not isinstance(covered, list)
            or any(not isinstance(i, str) for i in covered)
            or len(covered) != len(set(covered))
            or set(covered) != set(ids)):
        errs.append("intent_guard.review: requirements_covered must exactly match requirement IDs")
    if review.get("unapproved_changes") != []:
        errs.append("intent_guard.review: unapproved_changes must be an empty array")
    if not isinstance(review.get("evidence"), str) or not review["evidence"].strip():
        errs.append("intent_guard.review: evidence must be non-empty")
    return ids


def check_requirement_mapping(plan, requirement_ids, errs):
    tasks = plan.get("tasks") or []
    covered = set()
    known = set(requirement_ids)
    for task in tasks:
        if not isinstance(task, dict):
            continue
        tid = task.get("task_id", "?")
        refs = task.get("requirement_ids")
        if not isinstance(refs, list) or not refs:
            errs.append(f"{tid}: requirement_ids must map this task to original requirements")
            continue
        if any(not isinstance(i, str) for i in refs):
            errs.append(f"{tid}: requirement_ids must contain strings")
            continue
        if len(refs) != len(set(refs)):
            errs.append(f"{tid}: duplicate requirement_ids")
        unknown = set(refs) - known
        if unknown:
            errs.append(f"{tid}: unknown requirement_ids {sorted(unknown)}")
        covered.update(set(refs) & known)
    missing = known - covered
    if missing:
        errs.append(f"tasks do not cover original requirements: {sorted(missing)}")
    acceptance = (plan.get("intent_guard") or {}).get("acceptance")
    if (not isinstance(acceptance, dict) or not isinstance(acceptance.get("command"), str)
            or not acceptance["command"].strip()
            or not isinstance(acceptance.get("expect_exit_code"), int)
            or isinstance(acceptance.get("expect_exit_code"), bool)):
        errs.append("intent_guard.acceptance: original-purpose end-to-end acceptance is required")


def receipt_header(plan):
    guard = plan["intent_guard"]
    requirements = "; ".join(
        f"{r['id']}: {r['quote']} -> {r['outcome']}" for r in guard["requirements"]
    )
    return (f"# Source/spec review: {guard['source_ref']} + {plan['spec_ref']} "
            f"(reviewed by {guard['review_ref']})\n"
            f"# Original requirements: {requirements}\n"
            f"# Original-purpose acceptance: {guard['acceptance']['command']} "
            f"(exit {guard['acceptance']['expect_exit_code']})\n"
            "# Hashes prove receipt freshness only; they do not prove semantic alignment.\n")
