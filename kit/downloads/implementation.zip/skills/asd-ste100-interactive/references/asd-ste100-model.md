# ASD-STE100 Issue 9 — Component Model

This reference is a paraphrased working model, not a substitute for the official standard.

## Top-level structure

ASD-STE100 has two primary parts:

- **Part 1 — Writing rules**: 53 rules in 9 sections.
- **Part 2 — Dictionary**: controlled general vocabulary with approved meanings and parts of speech, plus non-approved entries and alternatives.

The standard also permits controlled **technical nouns** and **technical verbs** that are valid in the applicable company, industry, project, or subject field.

## Nine writing-rule sections

1. **Words** — approved vocabulary, meaning, part of speech, technical nouns/verbs, spelling, terminology discipline.
2. **Multi-word nouns** — keep noun groups short and make long official technical nouns clear.
3. **Verbs** — control verb forms, voice, and use of forms such as `-ing`.
4. **Sentences** — sentence length, sentence construction, lists, and connections between ideas.
5. **Procedural writing** — direct instructions, imperative form, action/condition order, notes and procedural clarity.
6. **Descriptive writing** — topic organization, paragraph discipline, active voice where practical, controlled description.
7. **Safety instructions** — warnings/cautions and clear presentation of hazards and actions.
8. **Punctuation and word count** — punctuation restrictions and special word-count conventions.
9. **Writing practice** — rewrite for clarity rather than word substitution alone; use terminology consistently.

## Relationship model

```text
                   ┌───────────────────────────┐
                   │       INPUT CONTENT       │
                   └─────────────┬─────────────┘
                                 │
                                 ▼
                   ┌───────────────────────────┐
                   │     TEXT TYPE / INTENT    │
                   │ Procedure / Description   │
                   │ Safety / Mixed            │
                   └─────────────┬─────────────┘
                                 │
              ┌──────────────────┴──────────────────┐
              ▼                                     ▼
   ┌───────────────────────┐             ┌───────────────────────┐
   │ PART 1: WRITING RULES │             │ PART 2: DICTIONARY    │
   │ 9 sections / 53 rules │             │ controlled vocabulary │
   └───────────┬───────────┘             └───────────┬───────────┘
               │                                     │
               ├──────────────┐          ┌───────────┤
               ▼              ▼          ▼           ▼
       Grammar/structure   Safety    Approved     Technical
       & word count        logic     vocabulary   nouns/verbs
               └──────────────┬──────────┬───────────┘
                              ▼
                   ┌───────────────────────────┐
                   │    CONSISTENCY / REVIEW   │
                   └─────────────┬─────────────┘
                                 ▼
                   ┌───────────────────────────┐
                   │  CLEAR TECHNICAL OUTPUT   │
                   └───────────────────────────┘
```

## Useful configurable defaults for an aid

These values are useful as defaults in a checker UI. They are not a replacement for reading the applicable rules in the official standard.

| Setting | Default |
|---|---:|
| Procedure sentence max words | 20 |
| Description sentence max words | 25 |
| Description paragraph max sentences | 6 |
| Multi-word noun max words | 3 |
| One instruction per procedure sentence | Yes |
| Active voice in procedures | Yes |
| Semicolon allowed | No |
| American English | Yes |
| Technical nouns/verbs allowed | Yes, when valid |

## Validation layers

### Reproducible software checks (not full official compliance)
- approximate sentence word count (official counting exceptions are not implemented);
- paragraph sentence count;
- semicolon presence;
- contraction presence (when configured);
- explicit forbidden-character/punctuation policies;
- exact dictionary lookup when authoritative data is supplied.

### Heuristic checks
- passive voice;
- multiple instructions in one sentence;
- `-ing` used as a verb rather than a noun/term;
- likely long multi-word noun groups;
- terminology inconsistency.

A heuristic flag must not be presented as proof of non-compliance.

The bundled HTML does not implement multi-word noun parsing, technical-term validation, terminology consistency, or dictionary import. These require a separate review or implementation.
