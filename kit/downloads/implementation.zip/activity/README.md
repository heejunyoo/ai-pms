# Harness Activity / AI PMS workflow kit

Local tools for carrying one explicit work cycle from a chosen phase and scope, through evidence and a review decision, into a concrete next Agent task. Python 3 standard library only; the viewer works offline.

## Try the workflow / 작업 흐름 시작

Open `viewer.html`. Choose **New project** to start without existing logs, or explicitly select `example-project.jsonl` to inspect the synthetic example. The example is fictional; it is not a log from a real account or project.

1. **Set the basis:** write the goal, included and excluded scope, phase name, and finish conditions. The viewer creates opaque project, phase, and baseline IDs while retaining the human text.
2. **Record changes and evidence:** add decisions with reasons, then register artifact versions and their checks or acceptance status. A decision records an addition or removal; it does not silently rewrite the selected baseline. Create a new baseline revision when the approved scope changes.
3. **Choose what carries forward:** explicitly select the baseline for the next task and confirm that it applies. Review the linked decision reasons and exact artifact versions. A recorded check or acceptance is a declared record, not independent proof that the artifact works.
4. **Hand off:** enter the next task and its acceptance conditions, then download the Markdown Agent packet. It contains the selected goal, scope, phase, finish conditions and only the relevant linked evidence. It is not sent to an Agent automatically.
5. **Save the project record:** download the project's full JSONL separately. New entries stay in browser memory until saved; unsaved changes are lost when the page closes. Reimport the saved JSONL to continue later.

The packet is a task brief, while project JSONL is the durable event record. Keep both when the next Agent needs context and future review needs history. Select artifact files only when you want a plain-text preview; previewed content is not uploaded, stored, or verified as the registered artifact version.

## Install the logger / 기록기 설치

Copy the exported `activity/` files to `~/.agents/harness-activity/`. Keep `logger.py`, `test_logger.py`, `viewer.html`, `README.md`, and `example-project.jsonl` together. Merge the command entries from your provider's setup guide into its existing hook configuration; preserve existing safety checks and settings. No account, hook configuration, or project log is included in this package.

```sh
python3 "$HOME/.agents/harness-activity/logger.py" hook --source codex
python3 "$HOME/.agents/harness-activity/logger.py" hook --source claude
python3 "$HOME/.agents/harness-activity/test_logger.py"
```

These commands consume provider JSON on stdin. Supported native names are SessionStart, UserPromptSubmit, PreToolUse, PostToolUse, Stop, SessionEnd; Claude also supplies PostToolUseFailure, SubagentStart, SubagentStop. Codex SubagentStop installation is deferred until its required stdout response is supported. Cursor/Gemini adapters are deferred. A passing stdin test does not prove that an installed app delivered a hook.

## Schema v1 / 스키마 v1

The logger schema is unchanged. Each JSONL event has the same fixed top-level fields, nullable correlation IDs, allowlisted `data`, and explicit `links`. `project.baseline` needs `phase_id` and `baseline_version`; `decision.recorded` also needs `decision_id`; artifact, check and acceptance records retain exact artifact/version links. The synthetic example uses only schema-v1 fields and labels its declared events as synthetic. Do not add workflow fields to the event contract; the viewer derives its workflow from the existing records.

An automatically logged project uses the logger's local cwd index, while a project created in the viewer gets its own UUID. To link them, either import the existing hook JSONL before adding baselines, or deliberately pass the viewer project's saved `project_id` to the logger's `hook --project-id` option. They do not join automatically.

An event's source and authority matter: native hook observations are observed; manually authored records are declared. Missing native IDs stay missing. Stop, successful tool calls, checks, and declared acceptance never imply that a project is complete.

## Privacy and limits / 개인정보와 한계

Default logs are daily JSONL files under `~/.local/state/harness-activity`; the local project index contains paths and is private. Share only project records you selected and reviewed. Never add private logs, credentials, local configuration, or personal paths to a public export. Explicit text is screened for common secrets and absolute paths, but the heuristic cannot detect every sensitive phrase.

The current kit provides local project authoring, explicit baseline selection, declared decisions and evidence, version-linked review, a downloadable next-task packet, and a separate full-record export. The viewer has no server or external transmission. Closing it discards unsaved edits.

Planned product work includes central sync, reliable automatic capture of decision semantics, and frame-specific planning views such as WBS, Gantt, and wireframes. These are future boundaries, not current capabilities. No semantic inference, project synchronization, or automatic task execution is claimed.

## 실무 흐름

`viewer.html`에서 기록 없이 새 프로젝트를 시작하거나 예시 파일을 직접 선택할 수 있습니다. 목표·포함/제외 범위·단계·완료 조건을 입력하고, 변경 판단은 이유와 함께 별도 기록합니다. 결과물은 버전별 검사·수락 상태와 연결해 검토합니다. 다음 Agent 작업에 적용할 기준을 직접 선택하고 확인한 뒤, 다음 작업 및 수락 조건을 입력해 Markdown 패킷을 받습니다. 프로젝트 JSONL 저장은 별도 동작입니다.

기준 변경 결정은 기존 기준을 자동 수정하지 않습니다. 변경된 범위가 승인되면 새 기준 버전을 기록하세요. 결정·검사·수락은 선언된 기록이며 실제 산출물 검증과 구분됩니다. 선택한 파일 미리보기 역시 등록된 버전과 일치함을 증명하지 않습니다. 패킷은 자동 전송되지 않습니다.


## MCP 연결 근거 v2 (오프라인)
MCP `mcp__server__tool` hook은 v2 `data.connection`에 안전한 이름과 호출 상태만 기록합니다. 일반 hook/명시 기록 v1은 그대로 지원합니다. Pre/Post는 각각 관측이며 완료 실행 두 건을 뜻하지 않습니다. 실제 데이터베이스 접근이나 산출물 활용을 추론하지 않습니다.

선택 `pms_metadata`는 정확히 `operation`, `resources`, `artifact_refs`만 받습니다. operation은 read/write/delete/unknown; resources는 최대32개 `{id,kind,label,evidence}`, kind는 database/document/repository/api/file/unknown, evidence는 declared/input/output입니다. artifact_refs는 최대32개 `{id,version}`의 명시적 참조입니다. URL·경로·SQL·비밀정보·원본 입력/출력은 금지합니다. 잘못된 메타데이터는 누락 표시와 함께 버립니다.

`hook --resource-map reviewed-map.json`은 로컬 검토한 raw tool name → 위 metadata 객체를 사용하며 모든 resource evidence를 declared로 강제합니다. 기본은 미설치이며 외부 통신은 없습니다. 도구 성공은 데이터 감사 증거가 아닙니다. duration_ms는 hook이 제공한 0..86400000 정수만 기록합니다. actor/environment 귀속은 중앙 manifest에서 유지합니다.

## Central management v3 / 중앙 관리 기록 v3

The central dashboard manages multiple users' persistent projects. The retained `viewer.html` is a personal offline reference. Local management JSON is separate from the logger's unchanged v1/v2 event contract. It is either one catalog project object with `management` or a v3 catalog (`version: 3`, `projects: [...]`); select exactly one catalog project with `--project-id`.

Copy `management_recorder.py`, `test_management_recorder.py`, and the identical portable `management.py` together. Start from the supplied v3 template and field guide, review the project identities and criteria, and explicitly list the artifact/test files. Python 3.11+ and POSIX file locking are required. These tools do not install hooks or send data.


For a runnable **synthetic smoke check** without manually calculating hashes, create a fresh project directory and copy the template as `management.json`. Leave its `example-project` criterion and identities intact for this smoke check; replace them with reviewed real requirements before using it for real work. The import creates a new test-plan version with actual file hashes. It does not execute the test.

```sh
mkdir -p ./my-project/checks
cp ~/.agents/harness-activity/catalog-v3.template.json ./my-project/management.json
printf '%s\n' '# Synthetic artifact only' > ./my-project/app.py
cat > ./my-project/checks/acceptance.py <<'PYTEST'
assert sum((1, 2)) == 3
PYTEST
cat > ./my-project/handoff-plan.json <<'JSONPLAN'
{"goal":"Synthetic smoke check only", "spec_ref":"smoke-source.md", "intent_guard":{"source_ref":"smoke-source.md","requirements":[{"id":"smoke-req","quote":"Verify synthetic local smoke behavior."}]}, "tasks":[{"task_id":"smoke","requirement_ids":["smoke-req"],"acceptance":{"command":"python3 checks/acceptance.py","expect_exit_code":0},"context":{"excluded":"Real product and provider behavior are not checked."}}]}
JSONPLAN
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id example-project \
  handoff --plan handoff-plan.json --plan-id implementation --version v2 \
  --reason 'Synthetic smoke-plan import; real behavior remains unverified.' \
  --test-file checks/acceptance.py \
  --actor-id ExampleUser --environment-id example-laptop --session-id smoke-session
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id example-project \
  run --test-plan handoff-smoke --version v2 \
  --actor-id ExampleUser --environment-id example-laptop --session-id smoke-session
```

The following commands show the same workflow after replacing the example identities and test-plan IDs with reviewed real ones:

```sh
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  run --test-plan acceptance --version v1 \
  --actor-id Alice --environment-id laptop --session-id session-1 \
  --environment local --timeout 300
python3 ~/.agents/harness-activity/test_management_recorder.py
```

`--project` must name a project directory, never HOME or the filesystem root. All management, Handoff and manifest filenames are normalized project-relative paths; `..`, absolute paths and symlinks escaping the project are rejected. The recorder validates mapped actor/environment and session identities before execution. It invokes the reviewed criterion command with `shlex` argv and `shell=False`, with stdin/stdout/stderr discarded and a timeout. Shell operators and environment expansion are not evaluated; use a checked project script for multi-step tests.

Only the explicitly listed artifact files are hashed. Coverage of that manifest is a user declaration, not proof that every relevant workspace file was included. Test-plan file hashes must match actual bytes before a test runs; changes require an explicit new test-plan version with a reason. The attempt retains the pre-run artifact hash. The management artifact gets actual post-run hashes. A changed artifact makes that receipt stale/unknown; it cannot establish current completion. Older attempts and signed plans are retained. If a file disappears after execution, the original management file is preserved and a safe separate `.ai-pms/receipt-*.json` is written. No raw output is stored. Runner provenance means this local process executed the command, not an external signature or assurance against fabricated JSON. Timeout/start failures retain exit_code=null and cannot pass even if a criterion expects124/127. The CLI returns the actual completed test exit code when available, `1` for interrupted/unstarted tests, `2` for recording errors; optional graph failure never replaces a test result.

```sh
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  handoff --plan handoff-plan.json --result handoff-result.json \
  --plan-id implementation --version v2 --reason 'Revised acceptance for the stated requirement.' \
  --test-file checks/acceptance.py \
  --actor-id Alice --environment-id laptop --session-id session-1
```

The helper seeds requirements from `intent_guard.requirements` with source references, plan/version/reason and versioned test plans from task acceptance. Each acceptance command/expected code must match exactly one existing project criterion; review the criteria first. Result `acceptance_run` is imported only as `provenance: declared`, even if it says complete or reports exit0. It never becomes an observed runner or current completion. Raw result `output_tail` is not copied. For real evidence, execute the matching test plan with `run`.

### Optional project Graphify wrapper / 선택적 프로젝트 그래프

Add `--graph` to `run`, or use the standalone `graph` subcommand after reviewing the project and installing Graphify separately. This is an opt-in project wrapper invocation suitable for an explicitly approved project-local hook; no global hook is installed or changed here.

```sh
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  graph --timeout 300
```

The wrapper invokes only `graphify extract <project> --code-only --no-cluster`, rejects HOME and a HOME git root, and rejects escaping output symlinks. It logs safe generator version when exposed, source revision/hash/time and generated/failed status into `management.graphs` and `.ai-pms/graphs.jsonl`. Failed generation does not block a test. A matching manifest/revision/version and validated graph file with a matching recorded digest can reuse a prior graph. Exit zero requires a newly written graph.json with valid nodes/edges and resolved endpoints; missing, corrupt or dangling artifacts are failed evidence. Freshness is current/stale/unknown; changed source hashes require revalidation. The hash covers the declared artifact manifest. An AST graph proves neither runtime integration nor test coverage. Semantic extraction, network APIs and automatic global installation are excluded.

회사 목표와 결과/작업 위임, 개인 프로젝트는 함께 관리하되 개인 프로젝트에 회사 목표 연결을 강제하지 않습니다. 테스트 계획에는 요구사항·계획 버전·설계 이유·제외 범위·파일 해시를 남깁니다. 실제 실행과 Handoff 결과 선언을 나누고, 산출물 또는 검사 정의가 바뀌면 과거 통과를 현재 완료로 승격하지 않습니다. 회사의 업무 성과는 기술 검사 통과와 별개로 **미관측**입니다.

막힘은 원인 가설/확정, 담당자, 다음 행동과 시도를 명시적으로 연결합니다. 개선 제안은 rule/harness/loop/skill/mcp 영역과 변경 버전, 근거/검증 시도를 기록하며 검증이 없으면 효과 미관측으로 남깁니다. 비활동 시간으로 막힘을 추정하거나 자동 생산성 점수를 만들지 않습니다. 그래프는 선택적 로컬 AST 근거입니다. 전역 훅·trust·원격 sender는 변경하지 않고, 공개 자료에는 합성 기록만 사용합니다. 실제 로그는 개인정보 검토 후 선택적으로 공유하세요.

Graphify 0.9.69의 실제 code-only 검사에서 외부 import를 가리키는 edge에 대응 node가 빠지는 경우를 확인했습니다. 이 경우 그래프를 성공으로 승격하지 않고 failed로 기록합니다. 검사 실행은 계속됩니다. 외부 의존성까지 분석하려면 생성기의 노드/edge 정합성을 보완한 뒤 다시 생성해야 합니다. 코드 구조의 부분 결과를 전체 런타임 근거로 사용하지 않습니다.

### 변경 체크포인트 · 판단 · 인계 · 기록 범위 / Traceability

Optional `management.traceability` connects code checkpoints, explicit decisions and alternatives, session handoff usage, and reported capture coverage. Existing v3 records without this object still work. It does not change technical completion criteria. Keep the four arrays `checkpoints`, `decisions`, `handoffs`, `capture`; the supplied field guide defines every field.

```sh
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  checkpoint --actor-id Alice --environment-id laptop --session-id session-1 \
  --agent-id codex --attempt-id attempt-reviewed --decision-id decision-reviewed \
  --summary 'Checkpoint for the reviewed requirement and matching test receipt.'
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  record --kind decision --record decision.json
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  record --kind handoff --record handoff-usage.json
python3 ~/.agents/harness-activity/management_recorder.py \
  --project ./my-project --management management.json --project-id my-project \
  record --kind capture --record capture-report.json
```

Omit optional `--attempt-id`/`--decision-id` when no matching evidence exists; repeat them for multiple references. A checkpoint reads Git HEAD, parent commits, NUL-delimited status, a binary diff against HEAD, and hashes of untracked regular files. It stores only commit identifiers and a worktree digest, never raw status/diff/file contents or commit messages. Git must cover exactly the explicit non-HOME project root; nested repositories outside that boundary and escaping/untracked symlinks are rejected. Git absent leaves commit/dirty/worktree fields null while the declared artifact manifest is still hashed. Git repositories without an initial HEAD commit are rejected; create and review the initial commit before using a Git checkpoint. The recorder compares Git fingerprints before and after observation and preserves the original JSON if they change. It never commits, stages, installs hooks, or calls a remote API.

The worktree digest covers Git's tracked diff/status and untracked regular project files; **ignored files and submodule contents are outside this coverage**. A checkpoint updates the explicitly listed artifact hashes; existing attempt links must match that exact revision and artifact hash. Git identity does not prove session authorship. Session/agent attribution is supplied by the operator and remains `provenance: declared`, even though the local command observed Git. Digests and imported JSON are not authenticated attestations.

`record` imports one exact decision, handoff, or capture object from a reviewed project-relative JSON file. Decisions preserve earlier decisions via `supersedes`, require explicit alternatives/reasons and reject cycles. Record the rationale you want to share, not private model reasoning. Handoff `usage: not_observed` stays unobserved; installing a skill, generating a packet or exporting a log never changes it to observed. Declared/observed usage requires a timestamp and concrete evidence; imported observed evidence is still not authenticated execution. Capture status is a historical source report with capabilities, observation time and reason, not a live heartbeat. Silence never establishes inactivity, completion, or unsupported tooling. All source tuples and referenced records must belong to the selected project; malformed imports preserve the original file.

변경 근거에서 목표·판단·세션·코드·검사를 이어 볼 수 있습니다. 판단 이유와 대안은 직접 작성하고, 인계 패킷을 만든 사실과 다음 세션이 실제로 사용한 근거를 구분합니다. 기록 중지·오류·미지원은 명시 보고로 남기며, 수집되지 않은 작업을 정체나 실패로 판단하지 않습니다. 자동 PC 수집·전역 훅 설치는 포함하지 않습니다.
