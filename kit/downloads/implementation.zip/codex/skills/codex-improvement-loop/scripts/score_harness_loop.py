#!/usr/bin/env python3
"""Local configuration inventory. Legacy filename; no capability score."""

from __future__ import annotations

import json
import subprocess
import sys
import tomllib
from pathlib import Path


HOME = Path.home()
CODEX = HOME / ".codex"
AUDIT = CODEX / "skills" / "codex-harness-audit"
LOOP = CODEX / "skills" / "codex-improvement-loop"


def contains(path: Path, *terms: str) -> bool:
    try:
        text = path.read_text(encoding="utf-8").lower()
    except OSError:
        return False
    return all(term.lower() in text for term in terms)


def check_harness() -> bool:
    checker = AUDIT / "scripts" / "check_harness.py"
    if not checker.exists():
        return False
    return subprocess.run(
        [sys.executable, str(checker)], capture_output=True, text=True, timeout=10
    ).returncode == 0


def main() -> int:
    config_ok = False
    try:
        tomllib.loads((CODEX / "config.toml").read_text(encoding="utf-8"))
        config_ok = True
    except (OSError, tomllib.TOMLDecodeError):
        pass

    checks = {"config_syntax": config_ok, "local_drift_checks": check_harness(),
              "loop_skill_present": (LOOP / "SKILL.md").exists()}
    report = {
        "kind": "configuration_inventory", "checks": checks,
        "not_measured": ["application hook delivery", "task correctness", "latency", "token cost"],
        "interpretation": "No maturity score. Global scheduling and project tests are not universal requirements.",
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
