#!/usr/bin/env python3
"""Fast, local drift checks for the supported Codex harness surfaces."""

from __future__ import annotations

import json
import re
import sys
import tomllib
from pathlib import Path


HOME = Path.home()
CODEX_HOME = HOME / ".codex"
SKILLS_DIRS = (CODEX_HOME / "skills", HOME / ".agents" / "skills")
NAME_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def frontmatter(path: Path) -> dict[str, str]:
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines or lines[0] != "---":
        raise ValueError("missing YAML frontmatter")
    try:
        end = lines.index("---", 1)
    except ValueError as exc:
        raise ValueError("unterminated YAML frontmatter") from exc
    values: dict[str, str] = {}
    for line in lines[1:end]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def main() -> int:
    failures: list[str] = []
    config = CODEX_HOME / "config.toml"
    if config.exists():
        try:
            tomllib.loads(config.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError) as exc:
            failures.append(f"invalid config.toml: {exc}")

    hooks = CODEX_HOME / "hooks.json"
    if hooks.exists():
        try:
            payload = json.loads(hooks.read_text(encoding="utf-8"))
            if not isinstance(payload.get("hooks"), dict):
                failures.append("invalid hooks.json: top-level hooks must be an object")
        except (OSError, json.JSONDecodeError) as exc:
            failures.append(f"invalid hooks.json: {exc}")

    for root in SKILLS_DIRS:
        for skill in sorted(root.iterdir()) if root.exists() else []:
            if skill.name.startswith(".") or not skill.is_dir():
                continue
            definition = skill / "SKILL.md"
            if not definition.exists():
                continue
            label = f"{root.parent.name}/{skill.name}"
            try:
                meta = frontmatter(definition)
                body = definition.read_text(encoding="utf-8")
            except (OSError, ValueError) as exc:
                failures.append(f"{label}: {exc}")
                continue
            name = meta.get("name", "")
            description = meta.get("description", "")
            if name != skill.name or not NAME_RE.fullmatch(name):
                failures.append(f"{label}: frontmatter name must match its directory")
            if not description or description.startswith("["):
                failures.append(f"{label}: missing usable description")
            if root == HOME / ".agents" / "skills" and (".Codex" in body or ".claude" in body):
                failures.append(f"{label}: stale Claude or case-incorrect Codex path")

    if failures:
        print("Codex harness drift detected:", file=sys.stderr)
        for failure in failures:
            print(f"- {failure}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
