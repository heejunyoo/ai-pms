---
name: codex-harness-audit
description: Audit and improve Codex operational configuration after changes to global instructions, skills, plugins, or config. Use to detect configuration drift, perform an adversarial review of high-leverage Codex changes, or establish a lightweight, verified agent harness.
---

# Codex Harness Audit

Keep the Codex harness small, explicit, and testable. Preserve the supported hooks that are live in this environment without inventing undocumented events or payloads.

## Workflow

1. Inspect the live files before proposing a change. Treat `~/.codex/config.toml`, `~/.codex/hooks.json`, hook scripts, global skills, and any applicable `AGENTS.md` as high-leverage surfaces.
2. Put one behavioral rule in one authoritative place. Point to that source instead of copying its body into skills or project instructions.
3. Keep scopes clean: global skills must be reusable and path-neutral; project-specific workflows belong in that project's `.codex/skills/` or `AGENTS.md`.
4. For high-leverage changes, review the diff from a skeptical perspective: permissions and trust boundaries, unintended global impact, duplicate/conflicting instructions, unsupported configuration keys, and a missing regression check.
5. Run `scripts/check_harness.py`. Treat nonzero output as a concrete drift finding; fix it or record why it is intentionally accepted.
6. Verify the change using the narrowest relevant command. Stay quiet on success and report only actionable findings.

## Guardrails

- Do not add speculative plugins, tools, or global skills. Add them only for a current workflow.
- Do not add or alter hooks from undocumented event names or guessed payloads. A `PreToolUse` safety gate is live here; inspect its actual contract and add a focused regression case before changing it.
- Keep checks local, fast, deterministic, and network-free.
- Add a focused check whenever a new harness invariant is introduced.

## Verification

Run:

```sh
python3 ~/.codex/skills/codex-harness-audit/scripts/check_harness.py
```

The checker is intentionally silent on success. It verifies TOML and hook JSON syntax plus essential skill metadata; review scope placement during the audit itself.

For an actionable finding, identify the affected file, observed problem, and correction or missing check. If the technical wording is unclear and `asd-ste100-interactive` is installed, it can clarify the finding. Preserve uncertainty and verification scope. Keep successful checks silent; do not add a writing review to every audit.
