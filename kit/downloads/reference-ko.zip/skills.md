# 스킬 설치와 사용

스킬은 특정 작업에 필요한 판단 기준과 절차입니다. 번들에 포함된 스킬과 별도로 설치해야 하는 도구를 구분한 뒤, 사용하는 에이전트에서 로드와 실제 동작을 확인합니다.

## Handoff

### 사용할 때

사용자가 위임·핸드오프·Phase 실행을 요청하고, 독립 검증 가능한 작업으로 나눌 수 있을 때 씁니다.

### 기본값

부모 모델과 추론 수준을 상속합니다. 패킷 필드가 채워졌다는 이유로 low를 강제하지 않습니다.

## 전문가 분석과 독립 패널

### expert-panel

문제·가설·선택 기준을 구조화하는 단일 분석 절차입니다. 반드시 여러 에이전트를 쓰는 것은 아닙니다.

### independent-panel

중요한 결정에 서로 다른 책임을 가진 독립 초안과 한 번의 교차검토를 사용합니다. 다수결이나 직함으로 결론을 고르지 않습니다.

## ELI20 설명

### 하나의 깊이

낯선 용어부터 구성요소별 책임, 연결, 실제 흐름, 조건·예외·한계와 근거까지 설명합니다. 기존 eli5 호출명은 호환을 위해 유지합니다.

### 결과 검증

관계 탐색이 도움이 될 때 자기완결 HTML을 만듭니다. 모바일에서 상태 변화와 읽기 편한지를 확인합니다. 배포는 사용자가 요청·승인한 경우에만 합니다.

## STE 기반 기술 문서 명료화 · 한국어와 영어

### 역할

ELI20은 무엇을 어떤 순서로 충분히 설명할지, 이 스킬은 기술 문장을 어떻게 명확하게 쓸지 담당합니다. 별도 스킬로 필요할 때 함께 씁니다.

### 한국어 모드

주체·지시어·용어·행동 순서를 명확히 하되 조건·예외·부정·수치와 의무의 강도를 유지합니다. 영어 단어 수와 승인 사전은 적용하지 않습니다. 공식 한국어 STE 표준이 아닌 자체 가이드입니다.

### 설치

구현 ZIP의 skills/asd-ste100-interactive/ 폴더 전체를 Codex에서는 ~/.agents/skills/ 또는 ~/.codex/skills/에, Claude에서는 ~/.claude/skills/에 배치합니다. 같은 환경의 두 경로에 중복 설치하지 말고 기존 폴더는 백업 후 병합하세요.

### 호출 예시

$asd-ste100-interactive로 이 한국어 문서를 의미와 예외를 유지하면서 다듬어줘. ELI20 병용: $eli5와 $asd-ste100-interactive를 함께 써서 원리와 조건을 충분히 설명해줘.

### 직접 탐색과 검증

스킬의 assets/korean-writing-explorer.html은 한국어 유형별 예시와 검토 후보를, asd-ste100-explorer.html은 영어 STE 구조와 설정을 보여줍니다. HTML을 브라우저에서 여세요. 한국어 도구의 표현 탐지와 문장 길이는 참고용이며, 의미 보존·안전성·공식 준수를 자동 판정하지 않습니다. 영어 사전 승인도 공식 자료로 별도 확인합니다.

## 선택 설치 · Ponytail과 Graphify

### Ponytail

코딩 작업의 불필요한 구현을 줄이는 외부 플러그인입니다. ZIP에 포함되지 않습니다. Codex: codex plugin marketplace add DietrichGebert/ponytail → codex plugin add ponytail@ponytail. Claude Code: /plugin marketplace add DietrichGebert/ponytail → /plugin install ponytail@ponytail. /hooks에서 신뢰 상태를 확인하고 새 세션에서 동작을 확인합니다. Cursor·Gemini는 아래 원본 안내의 도구별 설치법을 따릅니다.

### Graphify

프로젝트 코드를 그래프로 탐색하는 별도 CLI/스킬입니다. ZIP에 포함되지 않습니다. uv tool install graphifyy → graphify --version → graphify install --platform codex(또는 claude, cursor, gemini) 순서로 설치합니다. 대상 에이전트마다 스킬 목록을 확인합니다. 프로젝트별 graphify-out/graph.json이 있을 때 graphify query "질문" --budget 1500으로 조회합니다. 그래프 생성은 명시적으로 선택한 프로젝트에서만 graphify extract <project> --code-only --no-cluster를 사용합니다. 기존 그래프는 변경 후 갱신해야 합니다.

### 검증의 경계

설치 파일·검사 통과와 실제 앱에서의 훅 호출은 다릅니다. Ponytail의 절감 효과는 별도 측정이 필요하고, Graphify의 로컬 AST 그래프는 실행 중 동작이나 문서 의미를 자동으로 증명하지 않습니다.

## 설치와 사용은 환경에 맞게

### Codex

공용 스킬은 ~/.agents/skills/, 개인 Codex 스킬은 ~/.codex/skills/를 확인합니다.

### Claude

~/.claude/skills/를 확인합니다. 같은 목적의 스킬도 도구명과 실행 계약은 환경마다 다를 수 있습니다.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/skills.html
