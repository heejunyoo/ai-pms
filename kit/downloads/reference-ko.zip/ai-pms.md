# 여러 사용자의 프로젝트를 중앙에서 이해하기.

AI PMS는 다수 사용자·환경·세션의 작업을 지속되는 프로젝트에 연결합니다. 목표, 단계별 문서, 검사와 MCP·데이터 참조를 원본 근거로 확인합니다.

## 무엇을 관리하나요?

### 프로젝트가 관리 단위입니다

한 사람의 여러 세션을 넘어 여러 사용자의 여러 세션을 모읍니다. 세션이 끝나도 프로젝트 목표, 문서 버전, 단계, Agent와 결과물의 연결은 이어집니다. 같은 이름·UUID라도 사용자와 환경이 다르면 자동 병합하지 않습니다.

### Kit와 중앙 화면의 역할

Kit의 로컬 훅은 공통 형식으로 관측을 남기고, 선언 기록은 목표·판단·문서·검사 기준을 보완합니다. 중앙 집계기는 명시적 프로젝트 연결을 적용하고 대시보드는 프로젝트 현황에서 문서·세션·원본 근거로 내려갑니다. activity/viewer.html은 개인용 오프라인 참고 도구이며 중앙 제품 화면은 아래 샘플입니다.

## 기록에서 완료 판정까지

### 한 프로젝트의 실제 흐름

사용자/환경 → 세션/Agent → 공통 이벤트 → 중앙 집계 → 프로젝트 목표·단계별 문서 → 현재 revision 검사. 작업 검사·단계 검사·프로젝트 전체 검사는 구분합니다. 현재 프로젝트 버전과 설정된 전체 완료 기준을 충족한 검사만 완료 판정에 사용합니다.

### 관측과 선언을 나눕니다

훅은 호출 이름과 요청·완료·실패를 관측합니다. 목표와 판단 이유는 훅에서 추측하지 않고 문서·계획·명시적 기록으로 보완합니다. 연결 실패·수집 지연·재검증·미관측은 완료로 바꾸지 않습니다.

## MCP와 데이터 참조 읽기

### MCP란?

MCP는 에이전트가 외부 도구를 호출하는 연결 방식입니다. 서버는 도구 묶음, tool은 개별 기능입니다. 관계는 프로젝트 → 사용자/환경/세션 → 서버/tool → 사용자·환경에 귀속된 논리 데이터 참조 → 명시적 결과물 참조로 읽습니다.

### 근거의 강도

configured와 reviewed resource-map은 declared입니다. requested/completed/failed/unknown은 도구 이벤트 관측이며 duration_ms는 어댑터가 제공한 값만 기록합니다. resources의 declared/input/output은 참조가 나온 위치이지 실제 DB 접근 감사 증거가 아닙니다. 성공한 도구 호출도 하위 데이터 접근이나 프로젝트 완료를 증명하지 않습니다.

### 빈칸과 충돌

서버·tool 식별이 없으면 unknown/null로 남깁니다. 같은 서버 별칭이나 데이터 label이 다른 사용자 환경의 자원을 합치지 않습니다. Pre/Post를 두 번의 완료 실행으로 세지 않으며, 알 수 없는 결과물 ID도 명시적 참조로만 표시합니다.

## 로컬 기록 예시와 안전 계약

### 합성 훅 stdin 확인

```sh
printf '%s\n' '{"hook_event_name":"PostToolUse","tool_name":"mcp__demo__lookup","pms_metadata":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"input"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}' | python3 ~/.agents/harness-activity/logger.py hook --source claude --project-id 11111111-1111-4111-8111-111111111111 --log-dir ./synthetic-logs
```

### 로컬 선언 map

```json
{"mcp__demo__lookup":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"declared"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}
```

### map 적용과 검사

검토한 JSON을 synthetic-resource-map.json으로 저장하고 위 hook 명령에 --resource-map ./synthetic-resource-map.json을 추가합니다. 매핑 자원 근거는 declared로 고정됩니다. python3 ~/.agents/harness-activity/test_logger.py를 실행하세요. stdin 검사는 실제 앱 훅 전달·신뢰의 증거가 아닙니다. 기존 설정 병합과 실제 새 세션 확인은 도구별 안내를 따릅니다.

### 저장 허용 범위

v1 이벤트는 유지하며 v2 connection은 server, tool, status, duration_ms, operation, resources, artifact_refs만 허용합니다. resources는 id/kind/label/evidence, artifact_refs는 id/version이며 각각 최대32개입니다. URL·경로·쿼리·토큰·raw input/output은 저장하지 않습니다. 잘못된 선택 메타데이터는 누락 표시와 함께 제외하고 잘못된 가져오기 데이터는 거절합니다.

## 샘플과 운영의 경계

### 공개 샘플

새 앱은 합성 데이터로 만든 정적 오프라인 대시보드입니다. JSON 가져오기·내보내기와 MCP · 데이터 탭을 살펴보세요. 운영 서버·관리자 인증·실시간 자동 수집 서비스는 아닙니다. 모르는 사용자 PC에서 자동 수집하는 단계는 후속 과제입니다.

### 배포와 권한

이 페이지와 ZIP은 참고 자료입니다. 원격 sender 설치, 계정·키·MCP trust 변경을 자동 실행하지 않습니다. 실제 다중 사용자 앱 전달, 수집 지연, 원본 결과물과 현재 버전 검사는 별도 운영 근거가 필요합니다.


Reference edition: 2026-09-30
https://harness-kit.vercel.app/ai-pms.html
