# 전체 계획에서 현재 위치를 확인하기.

사람별 프로젝트 목표·각 Phase의 목표·참고한 API/MCP·달성 상태를 먼저 보고, 세부 기록은 별도 분석 근거에서 확인합니다.

## Kit와 AI PMS의 전체 그림

### Kit와 AI PMS의 전체 그림

Kit의 범위, PMS의 목적·구성, 실제 작업 흐름, 구현/검증과 다음 운영 인수를 ELI20 전체 설명 페이지에서 한 주제씩 읽을 수 있습니다.

## 로그를 분석과 행동으로 연결하기

### 목표 중복은 제안만

목표·대상·성공 기준·범위를 비교해 중복 후보와 이유를 제안합니다. 같은 기술이나 공동 목표만으로 중복이라고 하지 않습니다. 사람이 협업·독립 유지·기각을 판단하며 모델이 자동 합치기나 완료 판단을 하지 않습니다.

### 그 외 로그의 쓰임

실패→수정→재검사 이력은 반복 막힘, 현재 계획·검사는 검증 누락, 스킬·규칙·MCP 기록은 개선 후보를 찾는 근거입니다. 관리자에게는 근거와 권장 행동이 있는 결과만 보여줍니다. 로그 수를 생산성으로 환산하지 않습니다.

### 현재 준비 범위

ZIP의 pms/docs/human-view-and-analysis.md에 구분 기준이 있고 pms/scripts/prepare_goal_analysis.py는 목표 비교 입력을 생성합니다. 모델은 호출하지 않습니다. 실제 AI 분석·경고 검증·수락/기각 저장은 아직 미구현입니다. 실제 자료는 비공개로 유지하고 공개 Vercel은 합성 샘플로 사용합니다.

## 판단 필요 처리함

### 기본 화면과 별도 처리함

기본 화면에서는 판단 필요 수와 링크만 표시합니다. 전체 처리함과 프로젝트 처리함은 별도 주소에서 열며 전체 처리함은 선택한 사람 필터를 유지합니다. 현재 work.interventions의 담당자·요청 이유·다음 행동과 관련 작업/단계 상세를 연결합니다.

### 귀속과 현재 근거

정상 ready/in_progress를 모두 긴급 요청으로 바꾸지 않습니다. 담당자가 없거나 Phase gate만 있는 항목은 프로젝트 범위로 표시합니다. 같은 Phase·같은 이유는 근거별로 묶어 펼치고 최신 snapshot에서 다시 계산합니다. 선언된 다음 행동이 없으면 추측하지 않습니다.

### 읽기와 실행의 경계

처리함은 읽기 전용입니다. 문서 기준의 막힘·다음 행동과 현재 검사 근거를 항목마다 구분하며 문서 기록을 현재 검사 요청으로 승격하지 않습니다. 권한 부여·승인·원격 실행·AI 경고 생성 기능은 추가하지 않습니다.

## 목표와 전체 단계 흐름

### 사람과 전체 계획

사람 선택 → 참여 프로젝트 → 전체 Phase 흐름 → 별도 Phase 상세로 이동합니다. 공동 프로젝트는 같은 카드에 참여자를 표시합니다. 기본 정보는 프로젝트 목표, Phase 목표, 달성 상태, 참고한 API·MCP입니다. 전체 흐름은 목표·담당에서 최종 인수까지 이어집니다.

### 흐름과 상태의 의미

연결선은 계획에 적힌 순서입니다. 선언되지 않은 의존성이나 날짜·기간·ETA를 만들지 않습니다. 단계 달성과 프로젝트 최종 인수는 구분하고, 달성·미달성·근거 없음은 기존 판정 결과를 그대로 표시합니다. 모바일에서는 같은 내용을 세로 흐름으로 읽습니다.

### 상세와 분석 근거

Phase 상세는 목표·달성 상태·API/MCP 세 항목을 유지합니다. 실제 판단 항목이 있으면 짧은 다음 판단 요약과 별도 처리함 링크를 보여줍니다. 작업 WBS·Gantt, 검사 명령·문서·세션·원본은 분석 근거에 보존하며 기본 상세에 전부 쌓지 않습니다.

### 참조와 문서상의 이력

설정·선언·호출 관측·데이터 획득을 구분합니다. 프로젝트 참조를 특정 Phase의 참조로 추정하지 않습니다. 문서상의 진척은 문서 날짜·발췌 출처를 보여주며 현재 runner 검사·인수는 미확인으로 유지합니다.

## 세션·북극성과 실시간 근거

### 사람의 세션에서 시작하기

사람을 선택해 여러 환경과 프로젝트에 걸친 세션의 목표, 실행 생명주기와 목표 검증·인수를 확인합니다. 종료된 세션의 목표가 실패할 수도 있고, 열린 세션의 연결 작업 검증이 끝날 수도 있습니다. 연결 작업에서 계획·검사·문서 근거로 내려갑니다.

### 북극성과 기여 근거

회사·팀 지표의 단위·기간·기준값·목표값과 실측을 봅니다. 선언·미래·기간 밖 관측은 성과 판정에서 제외합니다. 기여 제안·연결 확인·정의 변경 후 재확인을 구별하며 기술 검사 통과를 사업 성과로 바꾸지 않습니다. 개인 목표는 독립적으로 유지할 수 있습니다.

### 개별 로그와 관리 변경 동기화

선택 실행하는 송신기가 로컬 JSONL과 목표·작업·검사·승인 파일의 개별 변경을 감시합니다. 자체 호스팅 중앙 서비스는 인증·영속 저장·중복 방지·충돌 표시와 cursor 조회를 제공합니다. 연결 화면은 2초마다 변경을 조회하며 JSON 전체 재가져오기에 의존하지 않습니다. 실제 PC에서 중앙으로 보내는 외부 방향 연결을 사용합니다.

### Kit와 실제 검증 경계

activity/logger.py health 명령은 마지막 기록·오류를 확인합니다. 오류에서도 에이전트를 막지 않는 훅 종료코드를 기록 성공으로 간주하지 않습니다. ZIP의 pms/README와 pms/specs/ai-pms-live/README.md에서 합성 로컬 중앙 실행을 시작하세요. 공개 Vercel은 합성 정적 예시입니다. 실제 앱 훅 설치·trust·원격 두 환경 전달은 별도 확인하며 설정이나 실제 로그를 자동 공개하지 않습니다.

## 2026-10-02 · 사람·목표·Phase·작업 관리

### 사람별 책임 작업

사람을 선택하면 참여 프로젝트의 목표와 단계 달성을 봅니다. 공동 프로젝트는 하나로 유지하고 참여자를 함께 표시합니다. 책임 작업·의존성·완료 조건·검증은 별도 분석 근거에서 확인합니다.

### 관리자가 판단할 다음 행동

분석 근거에서 검사 실패·사람 검토·담당자/기준 누락·명시적 막힘과 다음 행동을 확인합니다. 일반 선행 작업 대기는 진행 대기로 구분합니다. 세션·MCP 호출 수로 진척이나 생산성을 계산하지 않습니다.

### Kit 계획과 완료 판정

완전한 Handoff 계획의 Phase·작업·의존성·완료 조건을 보존합니다. 필수 작업·모든 Phase 종료 검사·필요한 사람 승인·프로젝트 인수가 충족되어야 완료입니다. 기준이나 파일 변경은 과거 검증/승인을 재검토합니다. ZIP activity/catalog-work.template.json, work.py와 README에서 시작하세요.

### 명시적 기록과 지원 경계

update로 시작/막힘, review로 현재 파일·기준에 묶인 판단을 기록합니다. 결과 파일의 통과는 선언이며 runner 관측과 구분합니다. 작업 출력 문자열 조건은 사람 검토로 보존하며 단계/전체 출력 조건은 미지원으로 거부합니다. 새 live kit는 opt-in 증분 전송과 관리자 인증을 제공합니다. 실제 앱 훅·원격 두 환경 운영 인수는 별도입니다.

## 2026-10-02 업데이트 · 중앙 관리 v3

### 이번에 추가된 내용

회사 목표·개인 위임 → 요구사항 → 계획과 테스트 설계 이유 → 실패·수정·통과 → 현재 산출물 검증을 연결했습니다. 막힘의 담당자·다음 조치, 철칙·하네스·검증 루프·스킬·MCP 개선 근거와 선택적 Graphify 최신성도 확인할 수 있습니다.

### JSON 템플릿과 설명 위치

아래 직접 링크에서 전체 필드 설명과 v3 JSON 템플릿을 볼 수 있습니다. 구현 소스 ZIP의 activity/catalog-v3.template.json, activity/json-contracts.md, activity/README.md에도 포함됩니다. 목표·판단·검사 이유는 명시적으로 기록하고, runner는 실제 실행 결과를 남깁니다.

## 추가 반영 · 변경·판단·인계·기록 상태

### 변경과 검사 연결

checkpoint 명령은 실제 Git 커밋·부모·미커밋 변경 해시를 읽고 세션·에이전트 선언 및 같은 산출물 검사를 연결합니다. 판단은 대안·선택 이유·원문·대체 이력을 남깁니다. Git 전체 tree 검사나 작성자 인증으로 해석하지 않습니다.

### 인계 활용과 기록 상태

인계 packet hash와 이전·다음 세션을 연결합니다. 생성·전달은 활용 증거가 아니므로 미관측/선언/조회 근거를 구분합니다. 도구별 지원 범위·중지·오류·마지막 관측은 가져온 시점의 보고이며 실시간 heartbeat가 아닙니다. 기존 v3도 호환됩니다. activity/README.md의 checkpoint 및 record 명령과 전체 필드 설명을 참고하세요.

## 무엇을 관리하나요?

### 프로젝트가 관리 단위입니다

한 사람의 여러 세션을 넘어 여러 사용자의 여러 세션을 모읍니다. 세션이 끝나도 프로젝트 목표, 문서 버전, 단계, Agent와 결과물의 연결은 이어집니다. 같은 이름·UUID라도 사용자와 환경이 다르면 자동 병합하지 않습니다.

### Kit와 중앙 화면의 역할

Kit의 로컬 훅은 공통 형식으로 관측을 남기고, 선언 기록은 목표·판단·문서·검사 기준을 보완합니다. 중앙 집계기는 명시적 프로젝트 연결을 적용하고 대시보드는 프로젝트 현황에서 문서·세션·원본 근거로 내려갑니다. activity/viewer.html은 개인용 오프라인 참고 도구이며 중앙 제품 화면은 아래 샘플입니다.

## 목표·위임·검사 설계와 개선 근거

### 회사 목표와 개인 프로젝트

회사 목표를 결과 달성(outcome) 또는 작업 지시(task)로 개인에게 넘기고 담당자·수락 기준·원문을 연결합니다. 개인 프로젝트도 독립적으로 관리하며 회사 목표 연결을 강제하지 않습니다. 회사의 업무 성과는 기술 검사 통과와 별도로 미관측입니다.

### 왜 이 검사를 만들었나요?

requirements → plans의 버전·이유 → test_plans의 정의·설계 이유·제외 범위·파일 해시 → attempts의 실제 실행 영수증으로 연결합니다. 과거 계획과 시도를 보존하며 현재 revision·실제 산출물 해시·현재 검사 정의에 맞는 runner 기록만 완료 판정에 사용합니다. Handoff 결과 가져오기는 declared이며 실행 증거가 아닙니다.

### 막힘과 개선을 검토합니다

막힘은 원인 가설/확정·담당자·다음 행동·연결 시도를 명시적으로 기록합니다. 철칙(rule), harness, 검증루프(loop), skill, mcp 개선은 변경 버전·근거 시도·검증 시도와 제안/시험/채택/보류 결정을 연결합니다. 검증 없는 개선 효과는 미관측이며 비활동 시간이나 자동 점수로 추측하지 않습니다.

### 선택적 Graphify 근거

프로젝트 wrapper의 --graph 또는 graph 명령은 code-only/no-cluster AST 그래프를 만들고 버전·source revision/hash·시각·generated/failed와 최신성을 남깁니다. 동일한 선언 manifest와 실제 graph 파일이면 재사용할 수 있습니다. 생성 실패는 검사를 막지 않습니다. HOME 및 HOME Git 루트·프로젝트 밖 symlink는 거절합니다. 전역 훅은 설치하지 않으며 AST는 runtime 연결·검사 커버리지 증거가 아닙니다.

## 기록에서 완료 판정까지

### 한 프로젝트의 실제 흐름

사용자/환경 → 세션/Agent → 공통 이벤트 → 중앙 집계 → 프로젝트 목표·단계별 문서 → 현재 revision 검사. 작업 검사·단계 검사·프로젝트 전체 검사는 구분합니다. 현재 프로젝트 버전과 설정된 전체 완료 기준을 충족한 검사만 완료 판정에 사용합니다.

### 관측과 선언을 나눕니다

훅은 호출 이름과 요청·완료·실패를 관측합니다. 목표와 판단 이유는 훅에서 추측하지 않고 문서·계획·명시적 기록으로 보완합니다. 연결 실패·수집 지연·재검증·미관측은 완료로 바꾸지 않습니다.

## MCP와 데이터 참조 읽기

### MCP란?

MCP는 에이전트가 외부 도구를 호출하는 연결 방식입니다. 서버는 도구 묶음, tool은 개별 기능입니다. 관계는 프로젝트 → 사용자/환경/세션 → 서버/tool → 사용자·환경에 귀속된 논리 데이터 참조 → 명시적 결과물 참조로 읽습니다.

### 근거의 강도

configured와 reviewed resource-map은 declared입니다. requested/completed/failed/unknown은 도구 이벤트 관측이며 duration_ms는 어댑터가 제공한 값만 기록합니다. resources의 declared/input/output은 참조가 나온 위치이지 실제 DB 접근 감사 증거가 아닙니다. 성공한 도구 호출도 하위 데이터 접근이나 프로젝트 완료를 증명하지 않습니다.

### 빈칸과 충돌

서버·tool 식별이 없으면 unknown/null로 남깁니다. 같은 서버 별칭이나 데이터 label이 다른 사용자 환경의 자원을 합치지 않습니다. Pre/Post를 두 번의 완료 실행으로 세지 않으며, 알 수 없는 결과물 ID도 명시적 참조로만 표시합니다.

## 로컬 기록 예시와 안전 계약

### 합성 훅 stdin 확인

```sh
printf '%s\n' '{"hook_event_name":"PostToolUse","tool_name":"mcp__demo__lookup","pms_metadata":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"input"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}' | python3 ~/.agents/harness-activity/logger.py hook --source claude --project-id 11111111-1111-4111-8111-111111111111 --log-dir ./synthetic-logs
```

### 로컬 선언 map

```json
{"mcp__demo__lookup":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"declared"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}
```

### map 적용과 검사

검토한 JSON을 synthetic-resource-map.json으로 저장하고 위 hook 명령에 --resource-map ./synthetic-resource-map.json을 추가합니다. 매핑 자원 근거는 declared로 고정됩니다. python3 ~/.agents/harness-activity/test_logger.py를 실행하세요. stdin 검사는 실제 앱 훅 전달·신뢰의 증거가 아닙니다. 기존 설정 병합과 실제 새 세션 확인은 도구별 안내를 따릅니다.

### 저장 허용 범위

v1 이벤트는 유지하며 v2 connection은 server, tool, status, duration_ms, operation, resources, artifact_refs만 허용합니다. resources는 id/kind/label/evidence, artifact_refs는 id/version이며 각각 최대32개입니다. URL·경로·쿼리·토큰·raw input/output은 저장하지 않습니다. 잘못된 선택 메타데이터는 누락 표시와 함께 제외하고 잘못된 가져오기 데이터는 거절합니다.

## 샘플과 운영의 경계

### 공개 샘플

새 앱은 합성 데이터로 만든 정적 오프라인 대시보드입니다. JSON 가져오기·내보내기와 MCP · 데이터 탭을 살펴보세요. 운영 서버·관리자 인증·실시간 자동 수집 서비스는 아닙니다. 아래 Live Kit로 자체 호스팅·opt-in sender를 실행할 수 있습니다. 실제 앱 훅과 원격 운영 검증은 별도입니다.

### 배포와 권한

이 페이지와 ZIP은 참고 자료입니다. 원격 sender 설치, 계정·키·MCP trust 변경을 자동 실행하지 않습니다. 실제 다중 사용자 앱 전달, 수집 지연, 원본 결과물과 현재 버전 검사는 별도 운영 근거가 필요합니다.

## 관리 기록기 실행

### 실제 검사 실행

```sh
python3 ~/.agents/harness-activity/management_recorder.py --project ./my-project --management management.json --project-id my-project run --test-plan acceptance --version v1 --actor-id Alice --environment-id laptop --session-id session-1 --environment local --timeout 300
python3 ~/.agents/harness-activity/test_management_recorder.py
```

### 파일·영수증 경계

v3 template과 field guide를 먼저 읽고 management.json의 사용자·환경·기준·manifest를 검토합니다. management_recorder.py, management.py, test_management_recorder.py를 함께 배치합니다. shlex argv/shell=False로 실행하고 raw stdout/stderr는 저장하지 않습니다. test file 변경은 명시적 새 계획 버전이 필요하며 사후 산출물 변경은 stale/unknown입니다. 파일이 사라지면 관리 파일 원본을 유지하고 안전한 별도 receipt를 남깁니다. manifest 포괄성 및 runner JSON은 외부 신뢰 보증이 아닙니다.

### Handoff·그래프 사용

README.md의 handoff helper는 원문 요구사항·계획·검사 설계 이유와 결과 declared를 연결합니다. 검토한 기존 criterion과 명령·기대 exit code가 정확히 맞아야 합니다. 선택 graph helper는 프로젝트에만 실행하며 실제 훅 설치·원격 전송을 자동 실행하지 않습니다.

## 이번 개선과 남은 인수

### 채택한 범위

Rensei 조사에서 전체 Phase 흐름, 별도 판단 필요 처리함, 기본 상세 분리와 탐색 안정성을 이번 화면 개선에 적용합니다. 기존 검사 판정·현재 승인 유효성·세션→작업→Phase 근거·증분 갱신을 유지합니다. 20개 제안 전체나 실행 제어·AI 분석을 구현한 것은 아닙니다.

### 코드 구조와 확인

ZIP의 pms/docs/rensei-experience.md는 채택 범위와 검증 경계를, pms/docs/project-architecture.md는 정본 파일의 역할을 설명합니다. 프로젝트만 추출한 Graphify AST는 소스 탐색 자료이며 실제 통합·원격 전달·검사 커버리지의 증거가 아닙니다. 데스크톱 사용을 우선합니다. DOM 회귀검사와 실제 데스크톱 화면·이동·갱신 검증을 구분하며, 모바일 검증은 이번 인수 범위에서 제외합니다.


Reference edition: 2026-10-03
https://harness-kit.vercel.app/ai-pms.html
