# AI PMS 훅 추가

로컬 기록을 확인한 다음 중앙 대시보드 도입으로 이어갑니다.

## Kit에서 훅을 추가하고 GitHub에서 PMS를 도입합니다

### 포함 범위

Kit의 PMS 구성은 로컬 훅 기록기입니다. 기존 Codex·Claude 구성과 안전 훅에 기록 명령을 병합합니다. 중앙 대시보드·수신기·송신기는 GitHub에서 별도로 도입합니다. Kit은 자동 설치 프로그램이 아닙니다.

### 도입 가이드

https://github.com/heejunyoo/ai-pms/blob/main/docs/adoption.md 에서 다운로드 → 훅 확인 → 프로젝트 등록 → 대시보드 → 인증된 로컬 파일럿 순서를 따르세요.

## 설치와 관측을 차례로 확인합니다

### 1 · 파일 배치

implementation.zip의 activity/를 ~/.agents/harness-activity/에 복사합니다. logger.py와 connectivity.py를 함께 유지합니다. python3 ~/.agents/harness-activity/test_logger.py 로 로컬 검사를 실행합니다.

### 2 · 기존 설정 병합

Codex 또는 Claude 안내에 따라 기존 훅 설정을 백업하고 hook --source codex 또는 hook --source claude 명령을 병합합니다. SessionStart·PreToolUse·PostToolUse·Stop 등 실제 앱 이벤트를 새 세션에서 확인합니다. 기존 안전 훅을 보존합니다.

### 3 · GitHub로 이어갑니다

프로젝트 ID·사용자·환경을 검토해 등록하고 목표·단계·작업을 명시합니다. 정적 프로젝트 화면과 인증된 Live 파일럿은 별도 절차입니다. 원격 운영에는 추가 보안·운영 검증이 필요합니다.

## 연결 기록이 의미하는 범위를 확인합니다

### 메타데이터

선택 pms_metadata는 operation·resources·artifact_refs만 받습니다. --resource-map은 검토한 로컬 매핑을 사용하며 evidence를 declared로 표시합니다. input/output 근거, artifact revision은 명시적으로 구분합니다.

### 관측 한계

duration_ms는 이벤트가 제공한 값만 기록합니다. 도구 호출 성공은 데이터 활용·사용자 목적 달성·프로젝트 완료를 증명하지 않습니다. 원본 input/output, URL·SQL·비밀정보는 공유하지 않습니다.

## 훅 기록과 사람이 입력한 근거를 구분합니다

### 기록 위치

기본 기록은 ~/.local/state/harness-activity 아래의 로컬 JSONL입니다. 프로젝트 경로 인덱스는 개인 정보입니다. 선택해 검토한 기록만 공유하세요. 누락된 ID는 누락 상태로 남깁니다.

### 확인 수준

stdin 테스트 통과 → 실제 앱 훅 호출 확인 → 중앙 송수신 확인은 각각 다른 증거입니다. 이 Kit 빌드는 실제 앱의 훅 신뢰 승인이나 원격 다중 사용자 전달을 설치·증명하지 않습니다.

## 샘플과 실제 적용의 경계를 확인합니다

### 기본 도입 예시

https://ai-pms-dashboard.vercel.app 은 가상 프로젝트를 실제 도입과 같은 문서 기반 화면으로 보여줍니다. 계획이 있어도 현재 실행은 미확인입니다. recorded-example.html은 기록이 채워진 별도 합성 예제입니다.

### 전체 자료

https://ai-pms-dashboard.vercel.app/report.html 에서 제품 설명을 읽고 https://github.com/heejunyoo/ai-pms 에서 전체 소스와 검증 명령을 받으세요. Kit ZIP에는 중앙 pms/ runtime이 없습니다. 기존 오프라인 뷰어와 수동 기록 도구는 선택적 로컬 참고 자료입니다.

## 기존 스킬과 프로젝트에 적용하기

### AI PMS 안내

도입 안내는 사전 조건 → 실행 → 확인 근거 → 실패 시 행동으로 나눕니다. 화면은 진행 막힘·확인되지 않음·문서상 완료·현재 검증 완료를 구분합니다. 원인·담당자·다음 행동은 기존 기록만 사용합니다. 중앙 PMS의 도입 절차는 GitHub 안내를 따릅니다.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/ai-pms.html
