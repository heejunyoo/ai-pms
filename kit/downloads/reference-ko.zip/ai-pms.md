# 여러 사용자의 프로젝트를 중앙에서 이해하기.

AI PMS는 다수 사용자·환경·세션의 작업을 지속되는 프로젝트에 연결합니다. 목표, 단계별 문서, 검사와 MCP·데이터 참조를 원본 근거로 확인합니다.

## 무엇을 관리하나요?

### 프로젝트가 관리 단위입니다

한 사람의 여러 세션을 넘어 여러 사용자의 여러 세션을 모읍니다. 세션이 끝나도 프로젝트 목표, 문서 버전, 단계, Agent와 결과물의 연결은 이어집니다. 같은 이름·UUID라도 사용자와 환경이 다르면 자동 병합하지 않습니다.

### Kit와 중앙 화면의 역할

Kit의 로컬 훅은 공통 형식으로 관측을 남기고, 선언 기록은 목표·판단·문서·검사 기준을 보완합니다. 중앙 집계기는 명시적 프로젝트 연결을 적용하고 대시보드는 프로젝트 현황에서 문서·세션·원본 근거로 내려갑니다. activity/viewer.html은 개인용 오프라인 참고 도구이며 중앙 제품 화면은 아래 샘플입니다.

## 기록에서 완료 판정까지

### 한 프로젝트의 실제 흐름

사용자/환경 → 세션/Agent → 공통 이벤트 → 중앙 집계 → 프로젝트 목표·단계별 문서 → 현재 revision 검사. 작업 검사·단계 검사·프로젝트 전체 검사는 구분합니다. 현재 프로젝트 버전과 설정된 전체 완료 기준을 충족한 검사만 완료 판정에 사용합니다.

### 관측과 선언을 나눕니다

훅은 호출 이름과 요청·완료·실패를 관측합니다. 목표와 판단 이유는 훅에서 추측하지 않고 문서·계획·명시적 기록으로 보완합니다. 연결 실패·수집 지연·재검증·미관측은 완료로 바꾸지 않습니다.

## 목표·위임·검사 설계와 개선 근거

### 회사 목표와 개인 프로젝트

회사 목표를 결과 달성(outcome) 또는 작업 지시(task)로 개인에게 넘기고 담당자·수락 기준·원문을 연결합니다. 개인 프로젝트도 독립적으로 관리하며 회사 목표 연결을 강제하지 않습니다. 회사의 업무 성과는 기술 검사 통과와 별도로 미관측입니다.

### 왜 이 검사를 만들었나요?

requirements → plans의 버전·이유 → test_plans의 정의·설계 이유·제외 범위·파일 해시 → attempts의 실제 실행 영수증으로 연결합니다. 과거 계획과 시도를 보존하며 현재 revision·실제 산출물 해시·현재 검사 정의에 맞는 runner 기록만 완료 판정에 사용합니다. Handoff 결과 가져오기는 declared이며 실행 증거가 아닙니다.

### 막힘과 개선을 검토합니다

막힘은 원인 가설/확정·담당자·다음 행동·연결 시도를 명시적으로 기록합니다. 철칙(rule), harness, 검증루프(loop), skill, mcp 개선은 변경 버전·근거 시도·검증 시도와 제안/시험/채택/보류 결정을 연결합니다. 검증 없는 개선 효과는 미관측이며 비활동 시간이나 자동 점수로 추측하지 않습니다.

### 선택적 Graphify 근거

프로젝트 wrapper의 --graph 또는 graph 명령은 code-only/no-cluster AST 그래프를 만들고 버전·source revision/hash·시각·generated/failed와 최신성을 남깁니다. 동일한 선언 manifest와 실제 graph 파일이면 재사용할 수 있습니다. 생성 실패는 검사를 막지 않습니다. HOME 및 HOME Git 루트·프로젝트 밖 symlink는 거절합니다. 전역 훅은 설치하지 않으며 AST는 runtime 연결·검사 커버리지 증거가 아닙니다.

## MCP와 데이터 참조 읽기

### MCP란?

MCP는 에이전트가 외부 도구를 호출하는 연결 방식입니다. 서버는 도구 묶음, tool은 개별 기능입니다. 관계는 프로젝트 → 사용자/환경/세션 → 서버/tool → 사용자·환경에 귀속된 논리 데이터 참조 → 명시적 결과물 참조로 읽습니다.

### 근거의 강도

configured와 reviewed resource-map은 declared입니다. requested/completed/failed/unknown은 도구 이벤트 관측이며 duration_ms는 어댑터가 제공한 값만 기록합니다. resources의 declared/input/output은 참조가 나온 위치이지 실제 DB 접근 감사 증거가 아닙니다. 성공한 도구 호출도 하위 데이터 접근이나 프로젝트 완료를 증명하지 않습니다.

### 빈칸과 충돌

서버·tool 식별이 없으면 unknown/null로 남깁니다. 같은 서버 별칭이나 데이터 label이 다른 사용자 환경의 자원을 합치지 않습니다. Pre/Post를 두 번의 완료 실행으로 세지 않으며, 알 수 없는 결과물 ID도 명시적 참조로만 표시합니다.

## 로컬 기록 예시와 안전 계약

### 합성 훅 stdin 확인

```sh
printf '%s\n' '{"hook_event_name":"PostToolUse","tool_name":"mcp__demo__lookup","pms_metadata":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"input"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}' | python3 ~/.agents/harness-activity/logger.py hook --source claude --project-id 11111111-1111-4111-8111-111111111111 --log-dir ./synthetic-logs
```

### 로컬 선언 map

```json
{"mcp__demo__lookup":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"declared"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}
```

### map 적용과 검사

검토한 JSON을 synthetic-resource-map.json으로 저장하고 위 hook 명령에 --resource-map ./synthetic-resource-map.json을 추가합니다. 매핑 자원 근거는 declared로 고정됩니다. python3 ~/.agents/harness-activity/test_logger.py를 실행하세요. stdin 검사는 실제 앱 훅 전달·신뢰의 증거가 아닙니다. 기존 설정 병합과 실제 새 세션 확인은 도구별 안내를 따릅니다.

### 저장 허용 범위

v1 이벤트는 유지하며 v2 connection은 server, tool, status, duration_ms, operation, resources, artifact_refs만 허용합니다. resources는 id/kind/label/evidence, artifact_refs는 id/version이며 각각 최대32개입니다. URL·경로·쿼리·토큰·raw input/output은 저장하지 않습니다. 잘못된 선택 메타데이터는 누락 표시와 함께 제외하고 잘못된 가져오기 데이터는 거절합니다.

## 샘플과 운영의 경계

### 공개 샘플

새 앱은 합성 데이터로 만든 정적 오프라인 대시보드입니다. JSON 가져오기·내보내기와 MCP · 데이터 탭을 살펴보세요. 운영 서버·관리자 인증·실시간 자동 수집 서비스는 아닙니다. 모르는 사용자 PC에서 자동 수집하는 단계는 후속 과제입니다.

### 배포와 권한

이 페이지와 ZIP은 참고 자료입니다. 원격 sender 설치, 계정·키·MCP trust 변경을 자동 실행하지 않습니다. 실제 다중 사용자 앱 전달, 수집 지연, 원본 결과물과 현재 버전 검사는 별도 운영 근거가 필요합니다.

## 관리 기록기 실행

### 실제 검사 실행

```sh
python3 ~/.agents/harness-activity/management_recorder.py --project ./my-project --management management.json --project-id my-project run --test-plan acceptance --version v1 --actor-id Alice --environment-id laptop --session-id session-1 --environment local --timeout 300
python3 ~/.agents/harness-activity/test_management_recorder.py
```

### 파일·영수증 경계

v3 template과 field guide를 먼저 읽고 management.json의 사용자·환경·기준·manifest를 검토합니다. management_recorder.py, management.py, test_management_recorder.py를 함께 배치합니다. shlex argv/shell=False로 실행하고 raw stdout/stderr는 저장하지 않습니다. test file 변경은 명시적 새 계획 버전이 필요하며 사후 산출물 변경은 stale/unknown입니다. 파일이 사라지면 관리 파일 원본을 유지하고 안전한 별도 receipt를 남깁니다. manifest 포괄성 및 runner JSON은 외부 신뢰 보증이 아닙니다.

### Handoff·그래프 사용

README.md의 handoff helper는 원문 요구사항·계획·검사 설계 이유와 결과 declared를 연결합니다. 검토한 기존 criterion과 명령·기대 exit code가 정확히 맞아야 합니다. 선택 graph helper는 프로젝트에만 실행하며 실제 훅 설치·원격 전송을 자동 실행하지 않습니다.


Reference edition: 2026-09-30
https://harness-kit.vercel.app/ai-pms.html
