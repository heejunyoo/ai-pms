# Claude에 적용하기

Claude Code는 요청을 해석하고 도구를 호출하는 에이전트입니다. 이 페이지는 Claude의 지침·안전/Stop 훅·스킬을 기존 설정과 병합하는 절차입니다. 구현 ZIP의 claude/와 claude-handoff/ 폴더를 사용합니다.

## 1. 지침과 문서 배치

### CLAUDE.md

~/.claude/CLAUDE.md에 언어, DB·배포·API 변경 등 사전 승인 범위, 검증 명령을 둡니다. 프로젝트 CLAUDE.md에는 리포별 정보만 둡니다.

### 운영 문서

claude/docs/를 ~/.claude/docs/로 옮깁니다. 기존 권한과 연결 설정은 필요한 항목만 병합합니다.

## 2. 훅 연결

### 안전 훅

claude/safety_gate.py를 ~/.claude/hooks/에 옮깁니다. settings.json의 hooks.PreToolUse에 matcher: Bash|Edit|Write|MultiEdit와 스크립트의 python3 실행 명령을 등록합니다.

### Stop 훅

claude/session_gate.py와 test_session_gate.py를 같은 hooks/ 폴더에 둡니다. hooks.Stop에 session_gate.py의 python3 실행 명령을 등록합니다. 마지막 코드 편집 이후 검증 기록을 확인하며 세션당 최대 한 번 개입합니다.

## 3. 스킬 배치

### Claude 스킬

claude-handoff/를 ~/.claude/skills/handoff/로, claude/skills/의 각 폴더를 ~/.claude/skills/로 옮깁니다. 각 폴더의 SKILL.md와 보조 파일을 함께 유지합니다.

## 4. 적용 확인

### 회귀 검사

```sh
python3 ~/.claude/hooks/test_session_gate.py
python3 ~/.claude/skills/handoff/validate.py selftest
```

### 새 세션

CLAUDE.md와 스킬이 로드되는지, /hooks에 등록한 명령이 보이는지 확인합니다. 실제 작업의 훅 호출도 확인합니다. Stop 검사는 커스텀 검증 명령이나 셸을 통한 편집을 놓칠 수 있습니다.

## 5. 로컬 활동 기록과 근거 보기

### 공통 패키지 배치

구현 ZIP의 activity/ 폴더를 ~/.agents/harness-activity/로 옮깁니다. logger.py, test_logger.py, viewer.html, README.md, example-project.jsonl을 함께 유지합니다. 예시 JSONL은 합성 자료이며 직접 선택해 볼 수 있습니다. Python 표준 라이브러리만 사용하며 자동 설치는 하지 않습니다.

### 기존 훅에 병합

~/.claude/settings.json을 백업한 뒤 아래 hooks 항목의 명령을 각 이벤트의 기존 배열에 추가합니다. 기존 PreToolUse 안전 게이트와 Claude Stop 검사를 별도 명령으로 유지하세요. 설정 전체를 덮어쓰지 마세요. 설치된 앱 버전에서 지원하는 이벤트만 등록합니다.

### 명령 훅 참고 JSON

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ],
        "matcher": "*"
      }
    ],
    "PostToolUse": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ],
        "matcher": "*"
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "SessionEnd": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "PostToolUseFailure": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ],
        "matcher": "*"
      }
    ],
    "SubagentStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "SubagentStop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ]
  }
}
```

### 첫 작업 흐름

기록 없이 새 프로젝트를 만들거나 example-project.jsonl을 직접 선택합니다. 목표·포함/제외 범위·단계·완료 조건을 정한 뒤, 변경 이유와 결과물 버전별 검사·수락 상태를 기록하세요. 다음 작업에 쓸 기준을 직접 선택하고 다음 Agent 작업 및 수락 조건을 입력해 Markdown 패킷을 내려받습니다. 프로젝트 전체 JSONL 저장은 별도 동작입니다.

### 기록과 확인

기본 로그는 ~/.local/state/harness-activity/의 일별 JSONL입니다. python3 ~/.agents/harness-activity/test_logger.py로 로컬 검사를 실행한 뒤 새 세션에서 /hooks 등록·신뢰 상태와 실제 작업의 이벤트 기록을 확인하세요. 직접 stdin 검사 통과는 앱의 훅 전달 증거가 아닙니다. 수동 결정·검사·수락은 선언 기록이며 실제 산출물 검증을 대신하지 않습니다.

### 개인정보와 제품 경계

내보내기에는 선택된 코드와 합성 예시만 포함하고 개인 로그·계정 설정·비밀정보는 포함하지 않습니다. 로컬 인덱스는 다른 기기로 옮겨지지 않으므로 같은 프로젝트 ID를 유지하려면 --project-id를 명시하고 README.md를 따르세요. 미저장 화면 변경은 닫으면 사라집니다. 중앙 동기화, 결정 의미 자동 포착, WBS·간트·와이어프레임은 후속 제품 방향이며 현재 기능이 아닙니다. Cursor·Gemini 연결도 후속 범위입니다.


Reference edition: 2026-10-03
https://harness-kit.vercel.app/claude.html
