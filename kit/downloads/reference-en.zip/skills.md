# Install and use skills

A skill supplies criteria and procedures for a relevant task. Distinguish bundled skills from separately installed tools, then verify loading and real behavior in your agent.

## Handoff

### When to use it

Use it when the user requests delegation, handoff, or phased execution and the work can be divided into independently verifiable tasks.

### Defaults

Inherit the parent model and reasoning effort. A complete packet is not a reason to force low reasoning.

## Structured analysis and independent review

### expert-panel

A single-analyst procedure for framing problems, hypotheses, and decision criteria. It does not inherently require multiple agents.

### independent-panel

For consequential decisions, use independent drafts with distinct responsibilities and one cross-review. Do not choose by vote or job title.

## ELI20 explanations

### One depth

Define unfamiliar terms, distinguish component responsibilities, trace connections and a concrete flow, and retain conditions, exceptions, limits, and evidence. The eli5 invocation name remains for compatibility.

### Validate the result

Create self-contained HTML when exploring relationships helps. Check real state changes and readability on mobile. Publish only when requested or authorized.

## STE-inspired technical writing · Korean and English

### Role

ELI20 determines what to explain and how deeply. This separate skill clarifies technical sentences and can be used with ELI20 when needed.

### Korean mode

Clarify actors, references, terminology and action order while preserving conditions, exceptions, negation, quantities and obligation strength. English word limits and the approved dictionary do not apply. This is an adapted guide, not an official Korean STE standard.

### Install

Copy the complete skills/asd-ste100-interactive/ folder from the implementation ZIP to ~/.agents/skills/ or ~/.codex/skills/ for Codex, or ~/.claude/skills/ for Claude. Avoid duplicate installation in both Codex locations. Back up and merge an existing folder.

### Example requests

Use $asd-ste100-interactive to clarify this Korean technical document while preserving its meaning and exceptions. Combine it with $eli5 to explain the mechanisms and conditions fully, then clarify the wording.

### Explore and verify

Open assets/korean-writing-explorer.html in the skill for Korean examples and review candidates, or asd-ste100-explorer.html for the English STE structure and settings. Korean expression flags and sentence lengths are advisory; the tool does not verify meaning preservation, safety or official compliance. English dictionary approval also requires authoritative data.

## Apply STE with existing skills and projects

### AI PMS guidance

Separate prerequisites, actions, verification evidence and failure handling. Distinguish blocked work, unknown status, documentary completion and current verification. Use recorded causes, owners and next actions only. Follow the GitHub guide for central PMS adoption.

### Handoff procedures

Identify the actor, prerequisite, action, expected result and stopping condition. Preserve source quotations, JSON keys, commands and expected exit codes. Clear wording does not replace independent review or acceptance checks.

### Complete ELI20 explanations

Build the complete explanation first. Then clarify the wording. The STE edition retains the same product scope: terms, responsibilities, connections, flow, examples, conditions, exceptions, evidence and limits. One comparison example cannot replace the explanation.

### Analysis and verification results

Separate facts, inferences, unverified behavior, next actions and completion evidence in final reports. In independent panels, finish drafts and cross-review before editing final wording. Preserve counterevidence, minority views, reversal conditions and decision rules.

### Selective use

Do not require STE for every task. Use the installed skill when technical wording needs clarification. Edit for natural style only when requested, then recheck conditions, negation, obligations and scope. Dictionary approval needs separate verification. Korean guidance is an adaptation.

## Optional installs · Ponytail and Graphify

### Ponytail

An external plugin that helps avoid unnecessary code in coding tasks. It is not in this ZIP. For Codex, run codex plugin marketplace add DietrichGebert/ponytail, then codex plugin add ponytail@ponytail. For Claude Code, run /plugin marketplace add DietrichGebert/ponytail, then /plugin install ponytail@ponytail. Review trust in /hooks and verify behavior in a new session. Follow the upstream tool-specific instructions for Cursor and Gemini.

### Graphify

A separate project-graph CLI and skill, not in this ZIP. Run uv tool install graphifyy, graphify --version, then graphify install --platform codex (or claude, cursor, gemini) for each target agent. Confirm the skill appears in each agent. When a project has graphify-out/graph.json, run graphify query "question" --budget 1500. To create a local code graph, explicitly select a project and run graphify extract <project> --code-only --no-cluster; refresh it after changes.

### Verification boundary

Installed files and passing checks do not prove application hook delivery. Ponytail savings require measurement; a local Graphify AST graph does not prove runtime behavior or document meaning.

## Adapt installation and use to the environment

### Codex

Check ~/.agents/skills/ for shared skills and ~/.codex/skills/ for personal Codex skills.

### Claude

Check ~/.claude/skills/. Skills with the same purpose may use different tool names and execution contracts.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/skills-en.html
