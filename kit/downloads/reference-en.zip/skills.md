# Install and use skills

A skill supplies criteria and procedures for a relevant task. Distinguish bundled skills from separately installed tools, then verify loading and real behavior in your agent.

## Handoff

### When to use it

Use it when the user requests delegation, handoff, or phased execution and the work can be divided into independently verifiable tasks.

### Defaults

Inherit the parent model and reasoning effort. A complete packet is not a reason to force low reasoning.

## Structured analysis and independent review

### expert-panel

A single-analyst procedure for framing problems, hypotheses, and decision criteria. It does not inherently require multiple agents.

### independent-panel

For consequential decisions, use independent drafts with distinct responsibilities and one cross-review. Do not choose by vote or job title.

## ELI20 explanations

### One depth

Define unfamiliar terms, distinguish component responsibilities, trace connections and a concrete flow, and retain conditions, exceptions, limits, and evidence. The eli5 invocation name remains for compatibility.

### Validate the result

Create self-contained HTML when exploring relationships helps. Check real state changes and readability on mobile. Publish only when requested or authorized.

## Optional installs · Ponytail and Graphify

### Ponytail

An external plugin that helps avoid unnecessary code in coding tasks. It is not in this ZIP. For Codex, run codex plugin marketplace add DietrichGebert/ponytail, then codex plugin add ponytail@ponytail. For Claude Code, run /plugin marketplace add DietrichGebert/ponytail, then /plugin install ponytail@ponytail. Review trust in /hooks and verify behavior in a new session. Follow the upstream tool-specific instructions for Cursor and Gemini.

### Graphify

A separate project-graph CLI and skill, not in this ZIP. Run uv tool install graphifyy, graphify --version, then graphify install --platform codex (or claude, cursor, gemini) for each target agent. Confirm the skill appears in each agent. When a project has graphify-out/graph.json, run graphify query "question" --budget 1500. To create a local code graph, explicitly select a project and run graphify extract <project> --code-only --no-cluster; refresh it after changes.

### Verification boundary

Installed files and passing checks do not prove application hook delivery. Ponytail savings require measurement; a local Graphify AST graph does not prove runtime behavior or document meaning.

## Adapt installation and use to the environment

### Codex

Check ~/.agents/skills/ for shared skills and ~/.codex/skills/ for personal Codex skills.

### Claude

Check ~/.claude/skills/. Skills with the same purpose may use different tool names and execution contracts.


Reference edition: 2026-10-02
https://harness-kit.vercel.app/skills-en.html
