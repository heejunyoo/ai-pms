# How does an agent harness finish real work?

ELI20 for newcomers: define the terms, follow one file change, and see what the checks do and do not prove.

## The problem this solves

### The same agent on another computer

Even with the same model, results depend on which instructions it reads, which tools it can use, what is blocked before execution, and how completion is checked. Harness Kit is a reference for transferring that surrounding setup.

### Agent and harness

The agent interprets requests and calls tools. The harness is the instructions, skills, hooks, and verification around it. The kit is neither a model nor a standalone operating program.

### Reading path

Learn the terms and responsibilities below, then follow a fictional CSV export request end to end. Finally distinguish what ships in the kit from what needs separate setup or live verification.

## Start with the terms

### Instructions · AGENTS.md / CLAUDE.md

Environment and project guidance read by the agent. They state approval boundaries and project commands.

### Skill · SKILL.md

A procedure and criteria for a particular kind of task. Being installed does not make it an automatically executing program for every task.

### Hook

An automatic check at a tool or session event. It can block defined risky actions but cannot judge the meaning or quality of the final result.

### Tools and verification

Tools change files or external systems. Tests and browser checks observe the result. Passing a check is different from resolving the user-visible problem.

## Who is responsible for what?

### User request and agent

The request sets the goal and authorization scope. The agent reads relevant files, plans, and executes the work.

### Instructions and skills

Instructions provide durable local rules; skills provide task-specific procedures. Neither edits files on its own.

### Hooks and tools

Hooks check specified tool-call boundaries. A permitted tool then changes a file or external system.

### Verification and report

Tests and the real interface help confirm the result. The agent reports what was observed and what remains unverified.

## Fictional example · add a CSV export button

### 1 · Understand

The user requests CSV export from an existing list. The agent checks the data format and completion criteria, then asks whether a database or API contract change is needed.

### 2 · Find the code

The agent reads project instructions and relevant source. An existing Graphify graph can aid navigation, but it may be stale; inspect the current source.

### 3 · Implement within boundaries

The agent applies a relevant skill and edits files. Ponytail helps avoid unnecessary code. A hook may block a defined risky action such as recording a secret or deleting an existing test.

### 4 · Verify the result

Check the CSV content and the button in the real interface. Passing tests alone does not prove the download contents or mobile layout are correct.

### 5 · Decide completion

Report confirmed behavior and limits. If a database schema or API contract change becomes necessary, check the existing authorization scope and ask before an out-of-scope action.

## Distinguish the recurring mechanisms

### Use the selector below

Rules define approval boundaries; a harness is the operating setup; a loop is verification and retry; a graph maps relationships; a skill is a procedure used when relevant. Similar names do not mean identical jobs.

## What the kit transfers and what remains

### Included

Publicly shareable Codex and Claude instructions, hook code, skills, and setup guides. The ZIP is not an automatic installer.

### Separate setup

Ponytail and Graphify are optional external tools. Models, logins, API keys, MCP connections, personal memory, and project permissions are outside the kit.

### Levels of evidence

Verify file placement, then loading in a new session, then real hook delivery and the user interface. Static checks do not prove hook delivery, savings, or final task quality.

## Apply this to your agent

### Codex configuration

Compare and merge instructions, the safety hook, and skills with the current setup, then verify.

### Claude configuration

Compare and merge instructions, safety and Stop hooks, and skills with the current setup, then verify.

### Skill installation

Find locations and checks for ELI20 and optional tools.


Reference edition: 2026-10-03
https://harness-kit.vercel.app/guide-en.html
