# Set up Claude

Claude Code is the agent that interprets requests and calls tools. This page explains how to merge its instructions, safety and Stop hooks, and skills with an existing setup. Use the claude/ and claude-handoff/ folders in the implementation ZIP.

## 1. Place instructions and documents

### CLAUDE.md

Put language preferences, approval boundaries for DB, deployment, and API changes, and check commands in ~/.claude/CLAUDE.md. Keep repository-specific information in the project CLAUDE.md.

### Operating documents

Copy claude/docs/ to ~/.claude/docs/. Merge only the required entries into existing permissions and connection settings.

## 2. Connect hooks

### Safety hook

Copy claude/safety_gate.py into ~/.claude/hooks/. In settings.json, add hooks.PreToolUse with matcher: Bash|Edit|Write|MultiEdit and a python3 command pointing to the script.

### Stop hook

Place claude/session_gate.py and test_session_gate.py in the same hooks/ folder. Add a hooks.Stop entry running session_gate.py with python3. It checks verification after the latest observed code edit and intervenes at most once per session.

## 3. Place skills

### Claude skills

Copy claude-handoff/ to ~/.claude/skills/handoff/ and each folder under claude/skills/ into ~/.claude/skills/. Keep SKILL.md and supporting files together.

## 4. Verify

### Regression checks

```sh
python3 ~/.claude/hooks/test_session_gate.py
python3 ~/.claude/skills/handoff/validate.py selftest
```

### New session

Confirm that CLAUDE.md and skills load and /hooks lists the registered commands. Check hook invocations during real work. The Stop check can miss custom verification commands and edits made through shell.

## 5. Record local activity and review evidence

### Place the shared package

Copy activity/ from the implementation ZIP to ~/.agents/harness-activity/. Keep logger.py, test_logger.py, viewer.html, README.md, and example-project.jsonl together. The JSONL is synthetic and can be selected explicitly. It uses only the Python standard library and does not install itself.

### Merge with existing hooks

Back up ~/.claude/settings.json, then append the commands below to each existing event array under hooks. Keep the existing PreToolUse safety gate and Claude Stop check as separate commands. Merge entries without overwriting the full configuration. Register only events supported by the installed application version.

### Reference command-hook JSON

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ],
        "matcher": "*"
      }
    ],
    "PostToolUse": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ],
        "matcher": "*"
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "SessionEnd": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "PostToolUseFailure": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ],
        "matcher": "*"
      }
    ],
    "SubagentStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ],
    "SubagentStop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source claude",
            "timeout": 3
          }
        ]
      }
    ]
  }
}
```

### First work cycle

Start a project without logs or explicitly select example-project.jsonl. Set the goal, included and excluded scope, phase, and finish conditions. Record decision reasons and artifact versions with their check or acceptance status. Explicitly choose the basis for the next task, enter that Agent task and its acceptance conditions, and download the Markdown packet. Saving the complete project JSONL is a separate action.

### Record and verify

Daily JSONL logs default to ~/.local/state/harness-activity/. Run python3 ~/.agents/harness-activity/test_logger.py for local checks, then open a new session, review registration and trust in /hooks, and verify actual work events. Direct stdin checks do not prove application hook delivery. Declared decisions, checks and acceptance do not replace verification of the actual artifact.

### Privacy and product limits

The export contains selected code and a synthetic example, not private logs, account settings, or secrets. The private project index does not transfer between devices; specify --project-id for a shared project identity and follow README.md. Unsaved viewer changes disappear on close. Central sync, automatic decision-semantic capture, and WBS, Gantt, or wireframe views are future product direction, not current features. Cursor and Gemini hookup is also deferred.


Reference edition: 2026-10-03
https://harness-kit.vercel.app/claude-en.html
