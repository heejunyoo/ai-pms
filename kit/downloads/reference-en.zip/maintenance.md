# Check the setup

Verify files, loading in a new session, and actual execution in that order.

## Files and configuration

### Missing files

Check that every skill includes SKILL.md and its referenced files, and that each hook command points to an existing script.

### Failed checks

Run the commands in the tool-specific guide. Fix the file or setting named in the error, then rerun the relevant check.

## New session

### Instructions and skills

Start a new session at the target project root. Check the loaded global and project instructions and available skills.

### Hooks and connections

Use /hooks to check registration and trust, then inspect invocations during real work. After MCP login, confirm that the needed tools are available in the current session.

## When updating

### Merge changes

Back up existing files, compare the new bundle, and apply changes. Manage personal memories and project permissions in the target environment.


Reference edition: 2026-09-30
https://harness-kit.vercel.app/maintenance-en.html
