# Check the setup

Verify files, loading in a new session, and actual execution in that order.

## Files and configuration

### Missing files

Check that every skill includes SKILL.md and its referenced files, and that each hook command points to an existing script.

### Failed checks

Run the commands in the tool-specific guide. Fix the file or setting named in the error, then rerun the relevant check.

## New session

### Instructions and skills

Start a new session at the target project root. Check the loaded global and project instructions and available skills.

### Hooks and connections

Use /hooks to check registration and trust, then inspect invocations during real work. After MCP login, confirm that the needed tools are available in the current session.

## When updating

### Merge changes

Back up existing files, compare the new bundle, and apply changes. Manage personal memories and project permissions in the target environment.

## Checks and product acceptance

### From purpose to verification

Separate technical checks, product acceptance and user acceptance. In the existing spec, connect the source request to the question a user must answer, required data and sources, the result and action, and the verification method. Check UI changes through actual rendering and interaction.

### Verify the failed path

A keyboard pass after a pointer failure leaves the pointer path unverified. Preserve the distinct scope of synthetic checks, actual local delivery, remote delivery and deployed file comparisons. Record the target version and recheck after relevant changes.

### Change the approach after rejection

Correct clear goal mismatches immediately. After two failures with the same approach, record the rejected result, cause hypothesis, changed assumption and acceptance condition before a third attempt. Continue other work that can still progress. The shared procedure is in codex/docs/autonomous_coding.md or claude/docs/autonomous_coding.md in the download.


Reference edition: 2026-10-03
https://harness-kit.vercel.app/maintenance-en.html
