# Understand with ELI20. Readable and complete enough.

Start with terms, components, connections, a concrete flow, and the conditions and limits that matter.

## What does it cover?

### Terms and responsibilities

Distinguish products, services, platforms, data, and operators. Define what each component does.

### Connections and flow

Trace where information is stored, which tool retrieves it, and which tool changes the real state.

### Example and boundaries

Follow one concrete case end to end. Separate built-in behavior, configuration, external systems, and plans.

## Make interaction reveal something

### Controls

Choose a comparison toggle, a step-through sequence, or a variable that lets readers inspect a relationship.

### Validation

Check that the visible state actually changes. Verify text, overflow, and touch targets on a small screen.

## Example · a new customer inquiry

### Input

An agent opens an inquiry and retrieves the customer record and past conversation. An unconnected external channel requires configuration first.

### Process

AI may draft a response, but a refund or contract change requires a separate authorized action in the business system.

### Verify

Check sources, permissions, and execution logs. A successful draft is not proof that the business action completed.

## Scope explanation and publication

### Self-contained HTML

Prefer an artifact that does not depend on external runtime resources. Avoid requiring login simply to read the explanation.

### Publication

Publish when the user requests or authorizes it. Choosing not to publish does not itself require confirmation.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/eli5-en.html
