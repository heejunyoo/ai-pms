# Delegate the work. Transfer the evidence.

Parallelize when tasks are independent and verification boundaries are clear.

## Inspect current source first

### Task packet

Specify the goal, files and symbols, reference implementation, forbidden scope, and acceptance criteria. Refresh changed evidence rather than repeating all discovery.

### Baseline and expected failure

Separate the existing test state from new acceptance criteria. A regression reproduction may correctly fail before the fix.

## Anchor the user purpose to source evidence

### Source and requirements

Name the authoritative user request and relevant specification. Quote each requirement exactly from its source and connect it to an outcome. Matching keywords alone do not establish semantic alignment.

### Independent review and freshness

A reviewer other than the author reads the raw source and specification, then checks every requirement, scope changes, and alignment. Record both SHA-256 digests and review coverage. Any source or specification change makes the receipt stale; review again before emitting.

### Task mapping

Map every implementation and investigative task to requirement IDs, and cover every requirement across the plan. Express file ownership and dependencies separately.

### Acceptance against the original purpose

Define a command and expected exit code that check the original request through its user-facing flow. In the existing spec, connect the source request to the question a user must answer, required data and sources, the result and action, and the verification method. Passing code checks or matching hashes alone does not prove semantic alignment, reviewer independence, or user acceptance.

## Assign distinct responsibilities

### Dependencies

Define ownership to avoid simultaneous edits to the same file. Express prerequisites with depends_on.

### Reasoning and context

Inherit model and reasoning settings by default. Provide only the evidence needed by an independent task and preserve user overrides. Packet tool lists and budgets are not API permission enforcement.

## The parent verifies integration

### Returned evidence

Require commands actually run, results, changed files, and unmet criteria. A subordinate completion claim is not sufficient. The parent does not promote a check PASS to product acceptance outside its scope, and directly checks the path the user reported as failing.

### Closing a phase

Check acceptance criteria and conflicts between changes. Handle consequential operations such as deployment and database changes within the current authorization.

## Apply STE with existing skills and projects

### Handoff procedures

Identify the actor, prerequisite, action, expected result and stopping condition. Preserve source quotations, JSON keys, commands and expected exit codes. Clear wording does not replace independent review or acceptance checks.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/handoff-en.html
