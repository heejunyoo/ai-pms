# How does Harness Kit support agent work?

This STE-oriented guide explains the purpose, terms, components, work flow and verification limits of Harness Kit.

## Transfer the operating setup to another environment

### The same model can give different results

An agent reads instructions and uses tools. Checks before execution and checks for completion also affect the work. Results can differ if this setup changes, even with the same model. Harness Kit provides references for transferring this operating setup.

### The agent and harness have different jobs

The agent interprets the user request. It calls tools to do the work. The harness contains instructions, skills, hooks and verification procedures around the agent. Harness Kit provides setup files and guides. The kit is not a model or an independent program.

### Follow this reading order

Read the terms first. Identify each component and its connections. Follow the fictional CSV export task. Then distinguish the kit contents from the checks that need real execution.

## Identify the basic terms

### Instructions · AGENTS.md / CLAUDE.md

Instructions contain environment and project rules. The agent reads these rules during its work. They identify approval boundaries and project commands.

### Skill · SKILL.md

A skill contains procedures and criteria for a particular task. The agent reads a skill when the task needs it. An installed skill does not run automatically for every task.

### Hook

A hook is an automatic check at a tool call or session event. It can block defined risky actions. It does not judge the meaning or quality of the result.

### Tools and verification

Tools change the actual state of files, shells or external services. Tests and interface checks observe those changes. A passing check does not establish that the user problem is solved.

## Connect responsibilities from request to result

### User request → agent

The user request defines the goal and authorization scope. The agent reads the necessary files. The agent plans and executes the work.

### Instructions and skills → work method

Instructions provide durable environment rules. Skills provide specialist procedures for the task. Instructions and skills do not edit files by themselves.

### Hooks → tool execution

Hooks check defined tool-call boundaries. A matching condition can block a call. A permitted tool changes files or external systems.

### Verification → report

The agent uses tests and the actual interface to check the result. It reports confirmed results. It also reports the scope that remains unverified.

## Fictional task · add a CSV export button

### 1 · Confirm the request

The user requests CSV export from an existing list. The agent checks the data format. It checks the completion criteria. It first determines whether a database or API contract change is necessary.

### 2 · Find the code

The agent reads project instructions. It finds the list interface and export code. An existing Graphify graph can help navigation. The agent checks if that graph is current. The agent still reads the current source after it uses the graph.

### 3 · Implement within scope

The agent applies the necessary skill. It edits the files. Ponytail helps avoid unnecessary code. A hook can block defined actions, such as recording secrets or deleting existing tests.

### 4 · Check the actual result

The agent checks the CSV content. It clicks the actual button. It checks the downloaded file and the mobile interface. Passing tests alone do not establish that the file content or mobile interface is correct.

### 5 · Decide completion scope

The agent reports confirmed results and remaining limits. If a database schema or API contract change becomes necessary, it checks existing authorization. If the change is outside that scope, it obtains approval before execution.

## Distinguish five recurring mechanisms

### Rules · approval boundaries

Rules define environment-specific execution boundaries. The agent checks if an action is within the user authorization. It does not ask again about authorized work. It checks whether a new database change or external operation is within that scope. Leave ordinary implementation decisions to the agent. Requiring approval for every action stops progress.

### Harness · operating setup

The harness connects instructions to tools and observed results. Put environment facts in the entry point. Put narrow mechanical conditions in hooks. Put work procedures in skills. Files and local checks do not prove that the application calls the hooks correctly.

### Loop · change and verify again

A loop repeats the baseline check, change, verification and decision. A result rejected for missing the user purpose is also a failure. Correct a clear purpose mismatch immediately. After two failures with the same approach, check assumptions or change the approach before a third attempt. Continue other work that can progress. Document counts and automation counts do not establish maturity. Do not repeat without evidence or stop too early.

### Graph · relationships and dependencies

A graph shows relationships between tasks or components. If tasks A and B can be checked separately, show them as independent branches. Check the integrated result after the tasks are combined. A graph can also show a return path after failure. A list is sufficient for a simple sequence. Use a graph when its explanatory value justifies its maintenance cost.

### Skill · procedure when needed

A skill provides procedures and criteria for recurring specialist work. The agent selects a skill for the current request. It checks the result after it applies the procedure. A complete task packet still inherits the parent model and reasoning settings by default. Do not make a one-time request mandatory for every task. A skill must not replace the current user request.

## Distinguish contents and verification limits

### Included in the kit

The kit provides public implementation files for Codex and Claude instructions, hooks and skills. It also provides setup guides. The ZIP is not an automatic installer.

### Install or configure separately

Ponytail and Graphify are optional external tools. Install them separately. Models, logins, API keys, MCP connections, personal memory and project permissions are not in the kit. Configure these in the target environment.

### Check three levels

Place the files. Check instruction and skill loading in a new session. Check actual hook calls and the user interface during real work. Static checks do not prove application hook delivery, cost or time savings, or final work quality.

## Apply the kit to your agent

### Codex configuration

Back up the current instructions, safety hook and skills. Compare the kit files with the current setup. Merge the necessary entries. Check loading and actual behavior.

### Claude configuration

Back up the current instructions, safety hook, Stop hook and skills. Compare the kit files with the current setup. Merge the necessary entries. Check loading and actual behavior.

### Skill installation

Read the skills guide for ELI20 and STE installation locations and usage. Read the separate installation and check steps for Ponytail and Graphify.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/ste-en.html
