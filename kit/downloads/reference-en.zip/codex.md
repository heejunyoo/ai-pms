# Set up Codex

Codex is the agent that interprets requests and calls tools. This page explains how to merge instructions, a safety hook, and skills around it. ~/.codex and ~/.agents are default locations.

## 1. Place instructions and documents

### Global instructions

Put language preferences, approval boundaries for DB, deployment, and API changes, and check commands in ~/.codex/AGENTS.md. Keep repository commands and constraints in the project AGENTS.md.

### Operating documents

Copy codex/docs/ to ~/.codex/docs/. It contains guidance for confidence, task execution, memory curation, and graph usage.

## 2. Connect the safety hook

### File location

Copy codex/safety_gate.py to ~/.codex/hooks/safety_gate.py. In hooks.json, add a PreToolUse entry with matcher: Bash|apply_patch and a python3 command pointing to that script.

### Coverage

The hook checks protected writes and test deletion or disabling patterns. Shell examples in documentation are not treated as commands. Keep your sandbox and approval settings.

## 3. Place skills

### Shared skills

Copy handoff/ and each folder under skills/ into ~/.agents/skills/. Keep SKILL.md and supporting files together.

### Codex-specific skills

Copy the folders under codex/skills/ into ~/.codex/skills/. Use the current session model and reasoning settings; Handoff inherits them.

## 4. Verify

### Configuration and Handoff checks

```sh
python3 ~/.codex/skills/codex-harness-audit/scripts/check_harness.py
python3 ~/.agents/skills/handoff/validate.py selftest
```

### New session

Open a session at the project root and check AGENTS.md and the available skills. Use /hooks to review trust for the current definition, then check invocation records during real work.

## 5. Record local activity and review evidence

### Place the shared package

Copy activity/ from the implementation ZIP to ~/.agents/harness-activity/. Keep logger.py, test_logger.py, viewer.html, README.md, and example-project.jsonl together. The JSONL is synthetic and can be selected explicitly. It uses only the Python standard library and does not install itself.

### Merge with existing hooks

Back up ~/.codex/hooks.json, then append the commands below to each existing event array under hooks. Keep the existing PreToolUse safety gate and Claude Stop check as separate commands. Merge entries without overwriting the full configuration. Register only events supported by the installed application version.

### Reference command-hook JSON

```json
{
  "hooks": {
    "SessionStart": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source codex",
            "timeout": 3
          }
        ]
      }
    ],
    "UserPromptSubmit": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source codex",
            "timeout": 3
          }
        ]
      }
    ],
    "PreToolUse": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source codex",
            "timeout": 3
          }
        ],
        "matcher": ".*"
      }
    ],
    "PostToolUse": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source codex",
            "timeout": 3
          }
        ],
        "matcher": ".*"
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source codex",
            "timeout": 3
          }
        ]
      }
    ],
    "SessionEnd": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "python3 \"$HOME/.agents/harness-activity/logger.py\" hook --source codex",
            "timeout": 3
          }
        ]
      }
    ]
  }
}
```

### First work cycle

Start a project without logs or explicitly select example-project.jsonl. Set the goal, included and excluded scope, phase, and finish conditions. Record decision reasons and artifact versions with their check or acceptance status. Explicitly choose the basis for the next task, enter that Agent task and its acceptance conditions, and download the Markdown packet. Saving the complete project JSONL is a separate action.

### Record and verify

Daily JSONL logs default to ~/.local/state/harness-activity/. Run python3 ~/.agents/harness-activity/test_logger.py for local checks, then open a new session, review registration and trust in /hooks, and verify actual work events. Direct stdin checks do not prove application hook delivery. Declared decisions, checks and acceptance do not replace verification of the actual artifact.

### Privacy and product limits

The export contains selected code and a synthetic example, not private logs, account settings, or secrets. The private project index does not transfer between devices; specify --project-id for a shared project identity and follow README.md. Unsaved viewer changes disappear on close. Central sync, automatic decision-semantic capture, and WBS, Gantt, or wireframe views are future product direction, not current features. Cursor and Gemini hookup is also deferred.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/codex-en.html
