# Structure supports decisions. Evidence determines conclusions.

Separate facts, hypotheses, and conditions that remain unknown.

## Define the decision first

### Criteria

State the decision and the conditions that change its outcome. Remove overlapping dimensions and unsupported weights.

### Falsification

Ask what must be true for a hypothesis to hold, then check its most fragile assumptions against primary sources.

## Add independent perspectives when useful

### Independent drafts

Assign different questions and evidence scopes before sharing conclusions. Role-play alone does not create independence.

### Cross-review

Review the strongest counterargument and evidence that would reverse the conclusion once. Synthesize by facts and logic rather than votes or average scores.

## Make the result usable

### Uncertainty

Keep judgments conditional when key facts are unknown. Do not present small score differences as precise rankings.

### Scope

Do not turn a one-time request for expert review into an obligation for every future plan.


Reference edition: 2026-09-30
https://harness-kit.vercel.app/expert-panel-en.html
