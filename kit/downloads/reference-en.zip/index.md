# Use this setup in another environment.

Transfer the core Codex and Claude harness, then verify it. Install and check Ponytail and Graphify separately.

## Understand first, then transfer

### What transfers?

The instructions, skills, hooks, and verification around an agent. This does not clone the model or account.

### What should I read first?

Use the ELI20 guide to learn the terms and real workflow, then follow the setup guide for your agent.

### What counts as verified?

After placing files and running static checks, inspect loading in a new session and real tool calls and interface results.

## Setup steps

### 01 · Download

Get the implementation ZIP and the guide in your language. Paths assume the default home directories on macOS or Linux. Python 3.11 or later is required.

### 02 · Apply

Follow the Codex or Claude guide to place files and connect hooks. Back up existing settings, then merge the required entries.

### 03 · Check a new session

Confirm that instructions and skills load and hooks are trusted and invoked. Configure accounts, models, and MCP connections in the target environment.

## Ask your agent to apply it

### Provide this request and the extracted folder

```text
Read the Harness Kit guides in this folder and apply them to my environment.
Compare them with my existing Codex or Claude setup first.
Back up and merge instructions, hooks, and skills. Keep my accounts
and project permissions. Run the included checks and list what needs
verification in a new session. Separate applied items from items
that still need configuration.
```

## Tool-specific guides

### Codex configuration

AGENTS.md, PreToolUse hooks, skill locations, and check commands.

### Claude configuration

CLAUDE.md, safety and Stop hooks, and check commands.

### Shared skills

Installation locations and example requests for each skill.

### AI PMS central projects

Review multiple users’ goals, step documents, current-revision checks and MCP/data references centrally.

## What transfers

### Included

Shared hook code, skill definitions and supporting files, and operating guidance. The ELI pages explain how the components work.

### Configure separately

External tools such as Ponytail and Graphify, logins, API keys, MCP connections, model selection, personal memories, and project permissions are not copied. Behavior still depends on the model, tools, and application version.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/index-en.html
