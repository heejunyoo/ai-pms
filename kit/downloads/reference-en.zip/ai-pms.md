# Add AI PMS hooks

Verify local capture, then continue to central dashboard adoption.

## Add hooks with Kit; adopt PMS through GitHub

### Scope

The PMS part of Kit provides local hook capture. Merge logging commands into existing Codex or Claude settings and retain safety hooks. Adopt the central dashboard, receiver and sender separately from GitHub. The ZIP is not an installer.

### Adoption guide

Follow https://github.com/heejunyoo/ai-pms/blob/main/docs/adoption.md : download, verify hooks, register projects, render the dashboard, then try the authenticated local pilot.

## Check setup and observations in order

### 1 · Place files

Copy activity/ from implementation.zip to ~/.agents/harness-activity/. Keep logger.py and connectivity.py together. Run python3 ~/.agents/harness-activity/test_logger.py.

### 2 · Merge existing settings

Follow the Codex or Claude guide. Back up existing settings and merge hook --source codex or hook --source claude. Verify actual SessionStart, PreToolUse, PostToolUse and Stop events in a new session. Preserve safety hooks.

### 3 · Continue in GitHub

Review project, actor and environment identities; explicitly author goals, phases and tasks. Static views and authenticated Live pilots have separate instructions. Remote operation requires further security and operating validation.

## Understand connection evidence

### Metadata

Optional pms_metadata accepts operation, resources and artifact_refs only. --resource-map uses reviewed local mappings with declared evidence. Distinguish explicit input/output evidence and artifact revision.

### Limits

duration_ms is recorded only when supplied by the event. Successful tool calls do not prove data usage, user acceptance or project completion. Never share raw input/output, URLs, SQL or secrets.

## Separate observed hooks from authored evidence

### Local storage

Default JSONL records are under ~/.local/state/harness-activity. The local path index is private. Share only selected, reviewed records. Missing native IDs remain missing.

### Verification levels

Passing stdin tests, observing native application hooks, and verifying central transport are separate evidence. This build does not install or prove native hook trust or remote multi-user delivery.

## Understand the sample and deployment boundary

### Default example

https://ai-pms-dashboard.vercel.app displays fictional projects in the same document-first view used for adoption. Plans do not confirm current execution. recorded-example.html separately retains synthetic recorded operations.

### Full project

Read https://ai-pms-dashboard.vercel.app/report.html and get the full source from https://github.com/heejunyoo/ai-pms. Kit ZIP has no central pms/ runtime. Existing offline viewers and manual recorders remain optional local references.


Reference edition: 2026-10-05
https://harness-kit.vercel.app/ai-pms-en.html
