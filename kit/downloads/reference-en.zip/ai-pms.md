# See the whole plan and where work stands.

Follow each person’s project goals, all phases and remaining completion conditions; inspect ownership and next actions on a separate detail page.

## WBS and timeline

### Start with the plan

Select a person, then follow project goal → all phases → final completion check. Compare Phase and atomic task ownership and states beside timeline bars. Shared projects distinguish personal assignments from whole-project status.

### Inspect the selected phase

Navigate from the list to one project plan, then a separate task detail page. Read next action, owner, specific reason and completion conditions first; expand raw evidence when needed. Return to the same WBS context.

### Completion and schedule meaning

Phase connectors show declared plan order; actual task dependencies appear in detail. All phases can pass while project checks or acceptance remain unmet. Public Gantt dates are an explicitly authored fictional plan. Unscheduled real inputs use a Phase axis without inferred deadlines.

## People → sessions → goals → company and team north stars

### Start with a person’s sessions

Select a person to inspect session goals across environments and projects. Execution lifecycle and goal verification or acceptance are separate. An ended session can have failed goals; an open session can have verified work. Follow linked tasks to plans, checks and documents.

### North stars and contribution evidence

Compare metric units, periods, baselines, targets and measurements. Declared, future or out-of-period observations do not prove outcomes. Separate proposed links, confirmed declarations and reconfirmation after changes. Technical checks do not prove business impact. Personal goals may remain independent.

### Incremental logs and management changes

The opt-in sender watches local JSONL and individual changes to goals, work, checks and approvals. The self-hosted central service provides authentication, durable storage, deduplication, visible conflicts and cursor queries. Connected dashboards poll every two seconds without full JSON reimport. Participants connect outbound from their environments.

### Kit and validation boundaries

The activity/logger.py health command reports last writes and errors. Nonblocking hook exit codes do not prove capture success. Start the synthetic local central pilot with pms/README and pms/specs/ai-pms-live/README.md in the ZIP. Public Vercel remains a static synthetic example. Actual provider hook installation, trust and remote two-environment delivery need separate validation. Configuration and real logs are not published automatically.

## 2026-10-02 · People, goals, phases and tasks

### Responsible work by person

Select a person to see the goals and assigned work across their projects. Shared projects remain one record; selected-person counts and project totals are distinct. Open phases, tasks, dependencies, acceptance conditions and verification evidence.

### Concrete manager actions

The first view shows failed checks, human reviews, missing owners or acceptance conditions, explicit blockers and next actions. Ordinary dependency waits are distinguished from decisions. Session and MCP counts are not progress or productivity scores.

### Kit plans and completion

Full Handoff imports preserve phases, tasks, dependencies and acceptance conditions. Completion requires required tasks, every phase gate, required human reviews and project acceptance. Changed criteria or files invalidate old evidence. Start with activity/catalog-work.template.json, work.py and README in the ZIP.

### Explicit records and boundaries

Use update for declared work or blockers and review for decisions bound to current files and criteria. Imported passes remain declarations. Task output conditions require human review; unsupported phase/project output conditions are rejected. The new live kit supplies opt-in incremental delivery and manager authentication. Actual provider hooks and remote two-environment acceptance require separate evidence.

## 2026-10-02 update · Central management v3

### What changed

Connect company goals and delegation to requirements, plan and test-design reasons, fail/fix/pass attempts and current artifact checks. Inspect blocker owners/next actions, evidence for rule/harness/loop/skill/MCP improvements and optional Graphify freshness.

### Where to find the JSON template and guide

Use the direct links below for the complete field guide and v3 JSON template. The implementation ZIP also contains activity/catalog-v3.template.json, activity/json-contracts.md and activity/README.md. Goals, decisions and test reasons are explicit records; the runner records actual execution results.

## Added · Changes, decisions, handoffs and capture

### Changes and checks

The checkpoint command reads Git commits, parents and dirty-worktree digests and links explicit session/agent attribution and matching artifact checks. Decisions retain alternatives, reasons, requirements and superseded entries. These do not authenticate authors or prove whole-tree testing.

### Handoff use and capture status

Link handoff packet hashes and source/destination sessions. Creation or delivery does not prove use: separate unobserved, declared and observed read evidence. Capture support, pauses, errors and last observations are historical reports, not live heartbeats. Existing v3 remains compatible. See checkpoint/record commands in activity/README.md and the complete field guide.

## What does AI PMS manage?

### The project is the management unit

Go beyond one user’s sessions to multiple users and sessions. Goals, document versions, steps, Agents and artifacts persist after a session ends. Identical names or UUIDs in different user environments are not automatically merged.

### Kit and central responsibilities

Local Kit hooks record observations in a common format. Declared records add goals, rationale, documents and check criteria. Central aggregation uses explicit project links; the dashboard leads from portfolio to documents, sessions and original evidence. activity/viewer.html is a personal offline reference tool; the central product sample is linked below.

## Goals, delegation, test design and improvement evidence

### Company goals and personal projects

Delegate a company goal as an outcome or a task with owner, acceptance and source. Personal projects remain independently managed without a required company link. Business outcomes remain unobserved separately from technical check results.

### Why was this test designed?

Connect requirements → versioned plans/reasons → test-plan definitions/design reasons/exclusions/file hashes → actual execution attempts. Preserve history. Only runner receipts matching the current revision, actual artifact hash and current check definition can govern completion. Imported Handoff results are declared, not execution evidence.

### Review blockers and improvements

Record blocker hypotheses or confirmed causes, owners, next actions and attempts explicitly. Improvements to rule, harness, loop, skill or mcp connect change versions, evidence and validation attempts with proposed/trial/adopt/hold decisions. Effects without validation remain unobserved; inactivity and automatic productivity scores do not establish a cause.

### Optional Graphify evidence

The project wrapper --graph option or graph command produces code-only/no-cluster AST evidence with generator version, source revision/hash, time, generated/failed status and freshness. Matching declared manifests with an existing graph file can be reused. Graph failure never blocks tests. HOME, a HOME git root and escaping symlinks are rejected. No global hooks are installed; AST graphs do not establish runtime integration or test coverage.

## From records to completion

### A project’s flow

User/environment → session/Agent → common events → central aggregation → project goal and documents by step → checks for the current revision. Task, phase and whole-project checks have separate scope. Only checks for the current project revision satisfying configured whole-project criteria govern completion.

### Separate observations and declarations

Hooks observe call identities and requested/completed/failed states. Goals and rationale come from documents, plans and explicit records rather than guesses. Connection failures, collection delay, revalidation and missing observations never become completion.

## Read MCP and data references

### What is MCP?

MCP connects an agent to external tools. A server groups tools; a tool is one function. Read the path as project → user/environment/session → server/tool → scoped logical data reference → explicit artifact reference.

### Evidence strength

Configured catalog rows and reviewed resource maps are declared. requested/completed/failed/unknown are tool-event observations; duration_ms is recorded only when an adapter provides it. Resource evidence declared/input/output identifies where a reference came from, not a downstream database audit. Tool success proves neither actual data access nor project completion.

### Missing identities and collisions

Missing server/tool identities remain unknown/null. Shared aliases or resource labels never merge different user environments. Pre/Post observations are not two completed executions. Unknown artifact IDs remain explicit references, not verified artifact use.

## Local examples and safe contract

### Synthetic hook stdin check

```sh
printf '%s\n' '{"hook_event_name":"PostToolUse","tool_name":"mcp__demo__lookup","pms_metadata":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"input"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}' | python3 ~/.agents/harness-activity/logger.py hook --source claude --project-id 11111111-1111-4111-8111-111111111111 --log-dir ./synthetic-logs
```

### Locally declared map

```json
{"mcp__demo__lookup":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"declared"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}
```

### Apply a map and check

Save reviewed JSON as synthetic-resource-map.json and append --resource-map ./synthetic-resource-map.json to the hook command above. Mapped resource evidence is forced to declared. Run python3 ~/.agents/harness-activity/test_logger.py. Stdin checks do not prove application hook delivery or trust. Follow the tool guides for merging existing settings and verifying a real new session.

### Allowed storage

v1 events remain valid. A v2 connection allows only server, tool, status, duration_ms, operation, resources and artifact_refs. Resources have id/kind/label/evidence; artifact_refs have id/version, with at most32 of each. URLs, paths, queries, tokens and raw inputs/outputs are excluded. Invalid optional metadata is dropped with missing-field markers; invalid imports are rejected.

## Sample and operational limits

### Public sample

The new app is a static offline dashboard with synthetic data. Explore JSON import/export and the MCP · data tab. It provides no operational backend, administrator authentication or live automatic collection service. Use the Live Kit below for a self-hosted service and opt-in sender. Actual provider hook trust and remote operational delivery need separate verification.

### Deployment and permissions

Pages and ZIPs are references. They do not automatically install a remote sender or change accounts, keys or MCP trust. Real multi-user application delivery, collection delay, original artifacts and current-revision checks need separate operational evidence.

## Run the management recorder

### Execute an actual check

```sh
python3 ~/.agents/harness-activity/management_recorder.py --project ./my-project --management management.json --project-id my-project run --test-plan acceptance --version v1 --actor-id Alice --environment-id laptop --session-id session-1 --environment local --timeout 300
python3 ~/.agents/harness-activity/test_management_recorder.py
```

### Files and receipt boundaries

Read the v3 template and field guide, then review management.json identities, criteria and manifest. Keep management_recorder.py, management.py and test_management_recorder.py together. Commands use shlex argv/shell=False; raw stdout/stderr is omitted. Changed test files require an explicit new plan version; post-run artifact changes make receipts stale/unknown. Missing files preserve the original management file and a safe separate receipt. Manifest coverage and runner JSON provide no external trust guarantee.

### Handoff and graph use

The README handoff helper links source requirements, plans, test-design reasons and declared results. Commands and expected exit codes must exactly match reviewed existing criteria. Optional graph helpers run only on the selected project; they do not automatically install hooks or remote delivery.


Reference edition: 2026-10-02
https://harness-kit.vercel.app/ai-pms-en.html
