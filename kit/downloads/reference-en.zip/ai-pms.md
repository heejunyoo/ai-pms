# Understand multiple users’ projects in one central view.

AI PMS connects work across users, environments and sessions to persistent projects. Inspect goals, documents by step, checks, and MCP/data references with original evidence.

## What does AI PMS manage?

### The project is the management unit

Go beyond one user’s sessions to multiple users and sessions. Goals, document versions, steps, Agents and artifacts persist after a session ends. Identical names or UUIDs in different user environments are not automatically merged.

### Kit and central responsibilities

Local Kit hooks record observations in a common format. Declared records add goals, rationale, documents and check criteria. Central aggregation uses explicit project links; the dashboard leads from portfolio to documents, sessions and original evidence. activity/viewer.html is a personal offline reference tool; the central product sample is linked below.

## From records to completion

### A project’s flow

User/environment → session/Agent → common events → central aggregation → project goal and documents by step → checks for the current revision. Task, phase and whole-project checks have separate scope. Only checks for the current project revision satisfying configured whole-project criteria govern completion.

### Separate observations and declarations

Hooks observe call identities and requested/completed/failed states. Goals and rationale come from documents, plans and explicit records rather than guesses. Connection failures, collection delay, revalidation and missing observations never become completion.

## Read MCP and data references

### What is MCP?

MCP connects an agent to external tools. A server groups tools; a tool is one function. Read the path as project → user/environment/session → server/tool → scoped logical data reference → explicit artifact reference.

### Evidence strength

Configured catalog rows and reviewed resource maps are declared. requested/completed/failed/unknown are tool-event observations; duration_ms is recorded only when an adapter provides it. Resource evidence declared/input/output identifies where a reference came from, not a downstream database audit. Tool success proves neither actual data access nor project completion.

### Missing identities and collisions

Missing server/tool identities remain unknown/null. Shared aliases or resource labels never merge different user environments. Pre/Post observations are not two completed executions. Unknown artifact IDs remain explicit references, not verified artifact use.

## Local examples and safe contract

### Synthetic hook stdin check

```sh
printf '%s\n' '{"hook_event_name":"PostToolUse","tool_name":"mcp__demo__lookup","pms_metadata":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"input"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}' | python3 ~/.agents/harness-activity/logger.py hook --source claude --project-id 11111111-1111-4111-8111-111111111111 --log-dir ./synthetic-logs
```

### Locally declared map

```json
{"mcp__demo__lookup":{"operation":"read","resources":[{"id":"demo-doc","kind":"document","label":"Synthetic document","evidence":"declared"}],"artifact_refs":[{"id":"demo-result","version":"v1"}]}}
```

### Apply a map and check

Save reviewed JSON as synthetic-resource-map.json and append --resource-map ./synthetic-resource-map.json to the hook command above. Mapped resource evidence is forced to declared. Run python3 ~/.agents/harness-activity/test_logger.py. Stdin checks do not prove application hook delivery or trust. Follow the tool guides for merging existing settings and verifying a real new session.

### Allowed storage

v1 events remain valid. A v2 connection allows only server, tool, status, duration_ms, operation, resources and artifact_refs. Resources have id/kind/label/evidence; artifact_refs have id/version, with at most32 of each. URLs, paths, queries, tokens and raw inputs/outputs are excluded. Invalid optional metadata is dropped with missing-field markers; invalid imports are rejected.

## Sample and operational limits

### Public sample

The new app is a static offline dashboard with synthetic data. Explore JSON import/export and the MCP · data tab. It provides no operational backend, administrator authentication or live automatic collection service. Automatic collection from unknown users’ PCs remains deferred.

### Deployment and permissions

Pages and ZIPs are references. They do not automatically install a remote sender or change accounts, keys or MCP trust. Real multi-user application delivery, collection delay, original artifacts and current-revision checks need separate operational evidence.


Reference edition: 2026-09-30
https://harness-kit.vercel.app/ai-pms-en.html
